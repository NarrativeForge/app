import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Volume2, VolumeX, ArrowRight } from 'lucide-react';
import { colors } from '../tokens';

const VideoIntro = ({ onComplete, videoSrc = '/intro.mp4' }) => {
  const [isMuted, setIsMuted] = useState(false);
  const [showSkip, setShowSkip] = useState(true);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const videoRef = useRef(null);

  useEffect(() => {
    // Auto-play video at 0.75x speed
    if (videoRef.current) {
      videoRef.current.playbackRate = 0.75; // Slow down to 75% speed
      videoRef.current.play().catch(err => {
        console.log('Autoplay prevented:', err);
        // If autoplay fails, mute and try again
        setIsMuted(true);
        videoRef.current.muted = true;
        videoRef.current.play();
      });
    }
  }, []);

  const handleVideoEnd = () => {
    setIsTransitioning(true);
    setTimeout(() => {
      onComplete();
    }, 5000); // 5s shimmer transition
  };

  const handleSkip = () => {
    setIsTransitioning(true);
    setTimeout(() => {
      onComplete();
    }, 5000); // 5s shimmer transition
  };

  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  return (
    <motion.div
      className="fixed inset-0 z-[100] flex items-center justify-center bg-black overflow-hidden"
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 1 }}
    >
      {/* Video player */}
      <video
        ref={videoRef}
        className="absolute inset-0 w-full h-full object-cover"
        src={videoSrc}
        muted={isMuted}
        playsInline
        onEnded={handleVideoEnd}
        style={{
          filter: 'brightness(1.1) contrast(1.1) saturate(1.2)',
        }}
      />
      
      {/* Set playback speed to 0.75x */}
      <script
        dangerouslySetInnerHTML={{
          __html: `
            if (document.querySelector('video')) {
              document.querySelector('video').playbackRate = 0.75;
            }
          `,
        }}
      />

      {/* Vignette overlay */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: 'radial-gradient(circle, transparent 40%, rgba(0,0,0,0.8) 100%)',
        }}
      />

      {/* Controls overlay */}
      <AnimatePresence>
        {showSkip && (
          <motion.div
            className="absolute inset-0 flex items-center justify-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
          >
            {/* Mute/Unmute button - bottom left */}
            <motion.button
              onClick={toggleMute}
              className="absolute bottom-8 left-8 p-4 rounded-full backdrop-blur-xl border"
              style={{
                background: 'rgba(0, 0, 0, 0.6)',
                borderColor: `${colors.cyan}40`,
              }}
              whileHover={{
                scale: 1.1,
                boxShadow: `0 0 20px ${colors.glowCyan}`,
                borderColor: `${colors.cyan}80`,
              }}
              whileTap={{ scale: 0.95 }}
              transition={{ duration: 0.16 }}
            >
              {isMuted ? (
                <VolumeX size={24} color={colors.cyan} />
              ) : (
                <Volume2 size={24} color={colors.cyan} />
              )}
            </motion.button>

            {/* Enter/Skip button - bottom center */}
            <motion.button
              onClick={handleSkip}
              className="absolute bottom-8 left-1/2 -translate-x-1/2 px-12 py-6 rounded-full backdrop-blur-xl border flex items-center gap-4"
              style={{
                background: 'rgba(0, 0, 0, 0.7)',
                borderColor: `${colors.cyan}60`,
                boxShadow: `0 0 30px ${colors.glowCyan}, 0 0 60px ${colors.glowCyan}`,
              }}
              whileHover={{
                scale: 1.05,
                boxShadow: `0 0 40px ${colors.glowCyan}, 0 0 80px ${colors.glowCyan}`,
                borderColor: colors.cyan,
              }}
              whileTap={{ scale: 0.95 }}
              transition={{ duration: 0.16 }}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <span
                style={{
                  fontFamily: "'Michroma', sans-serif",
                  fontSize: '1.5rem',
                  color: colors.cyan,
                  textShadow: `0 0 10px ${colors.cyan}, 0 0 20px ${colors.cyan}`,
                  letterSpacing: '0.2em',
                }}
              >
                ENTER
              </span>
              <motion.div
                animate={{
                  x: [0, 5, 0],
                }}
                transition={{
                  duration: 1.5,
                  repeat: Infinity,
                  ease: 'easeInOut',
                }}
              >
                <ArrowRight size={28} color={colors.cyan} />
              </motion.div>
            </motion.button>


          </motion.div>
        )}
      </AnimatePresence>

      {/* Shimmer edge effect */}
      <motion.div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: `
            linear-gradient(90deg, 
              ${colors.cyan}20 0%, 
              transparent 10%, 
              transparent 90%, 
              ${colors.cyan}20 100%
            )
          `,
          mixBlendMode: 'screen',
        }}
        animate={{
          opacity: [0.3, 0.6, 0.3],
        }}
        transition={{
          duration: 2,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
      />

      {/* Shimmer portal transition overlay */}
      <AnimatePresence>
        {isTransitioning && (
          <motion.div
            className="absolute inset-0 z-50 pointer-events-none"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            {/* Liquid shimmer waves */}
            {[...Array(8)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute inset-0"
                style={{
                  background: `radial-gradient(circle at 50% 50%, 
                    ${i % 3 === 0 ? colors.cyan : i % 3 === 1 ? colors.violet : colors.mint}60,
                    transparent 60%
                  )`,
                  filter: 'blur(50px)',
                }}
                initial={{ scale: 0, opacity: 0 }}
                animate={{ 
                  scale: [0, 1.5, 2.5, 3.5],
                  opacity: [0, 0.9, 0.7, 0],
                }}
                transition={{
                  duration: 5.0,
                  delay: i * 0.2,
                  ease: 'easeOut',
                }}
              />
            ))}

            {/* Ripple rings */}
            {[...Array(6)].map((_, i) => (
              <motion.div
                key={`ring-${i}`}
                className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full border-4"
                style={{
                  borderColor: i % 2 === 0 ? colors.cyan : colors.violet,
                  boxShadow: `0 0 30px ${i % 2 === 0 ? colors.cyan : colors.violet}, inset 0 0 30px ${i % 2 === 0 ? colors.cyan : colors.violet}`,
                }}
                initial={{ width: 0, height: 0, opacity: 0 }}
                animate={{
                  width: ['0px', '600px', '1000px', '1400px'],
                  height: ['0px', '600px', '1000px', '1400px'],
                  opacity: [0, 0.8, 0.5, 0],
                }}
                transition={{
                  duration: 5.0,
                  delay: i * 0.25,
                  ease: 'easeOut',
                }}
              />
            ))}

            {/* Iridescent shimmer overlay */}
            <motion.div
              className="absolute inset-0"
              style={{
                background: `
                  radial-gradient(circle at 30% 40%, ${colors.cyan}50 0%, transparent 50%),
                  radial-gradient(circle at 70% 60%, ${colors.violet}50 0%, transparent 50%),
                  radial-gradient(circle at 50% 50%, ${colors.mint}40 0%, transparent 60%)
                `,
                filter: 'blur(80px)',
                mixBlendMode: 'screen',
              }}
              animate={{
                scale: [1, 1.3, 1.8, 2.5],
                opacity: [0, 0.9, 0.7, 0],
                rotate: [0, 90, 180, 360],
              }}
              transition={{
                duration: 5.0,
                ease: 'easeInOut',
              }}
            />

            {/* Particle burst */}
            {[...Array(20)].map((_, i) => (
              <motion.div
                key={`particle-${i}`}
                className="absolute w-1 h-1 rounded-full"
                style={{
                  left: '50%',
                  top: '50%',
                  background: i % 3 === 0 ? colors.cyan : i % 3 === 1 ? colors.violet : colors.mint,
                  boxShadow: `0 0 10px ${i % 3 === 0 ? colors.cyan : i % 3 === 1 ? colors.violet : colors.mint}`,
                }}
                initial={{ scale: 0, opacity: 0 }}
                animate={{
                  x: Math.cos((i * 18) * Math.PI / 180) * 400,
                  y: Math.sin((i * 18) * Math.PI / 180) * 400,
                  scale: [0, 2, 0],
                  opacity: [0, 1, 0],
                }}
                transition={{
                  duration: 1.5,
                  delay: i * 0.02,
                  ease: 'easeOut',
                }}
              />
            ))}

            {/* White flash at peak */}
            <motion.div
              className="absolute inset-0 bg-white"
              initial={{ opacity: 0 }}
              animate={{ opacity: [0, 0.5, 0.2, 0] }}
              transition={{
                duration: 2.0,
                delay: 2.0,
                ease: 'easeInOut',
              }}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

export default VideoIntro;

