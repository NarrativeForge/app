import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { colors } from '../tokens';

const ShimmerPortal = ({ onComplete }) => {
  const [phase, setPhase] = useState('shimmer'); // shimmer -> portal -> dissolve

  useEffect(() => {
    // Phase 1: Shimmer (0-2s)
    const shimmerTimer = setTimeout(() => {
      setPhase('portal');
    }, 2000);

    // Phase 2: Portal opening (2-4s)
    const portalTimer = setTimeout(() => {
      setPhase('dissolve');
    }, 4000);

    // Phase 3: Dissolve and complete (4-6s)
    const completeTimer = setTimeout(() => {
      onComplete();
    }, 6000);

    return () => {
      clearTimeout(shimmerTimer);
      clearTimeout(portalTimer);
      clearTimeout(completeTimer);
    };
  }, [onComplete]);

  return (
    <motion.div
      className="fixed inset-0 z-[100] flex items-center justify-center overflow-hidden"
      style={{
        background: 'radial-gradient(circle, #0a0f15 0%, #000000 100%)',
      }}
      initial={{ opacity: 1 }}
      animate={{ opacity: phase === 'dissolve' ? 0 : 1 }}
      transition={{ duration: 2, ease: 'easeInOut' }}
    >
      {/* Shimmer overlay - iridescent liquid effect */}
      <motion.div
        className="absolute inset-0"
        style={{
          background: `
            radial-gradient(circle at 30% 40%, ${colors.cyan}40 0%, transparent 50%),
            radial-gradient(circle at 70% 60%, ${colors.violet}40 0%, transparent 50%),
            radial-gradient(circle at 50% 50%, ${colors.mint}30 0%, transparent 60%)
          `,
          filter: 'blur(60px)',
        }}
        animate={{
          scale: phase === 'shimmer' ? [1, 1.2, 1] : phase === 'portal' ? [1, 1.5] : [1.5, 2],
          opacity: phase === 'shimmer' ? [0.3, 0.6, 0.3] : phase === 'portal' ? [0.6, 0.8] : [0.8, 0],
        }}
        transition={{
          duration: phase === 'shimmer' ? 2 : 2,
          ease: 'easeInOut',
          repeat: phase === 'shimmer' ? Infinity : 0,
        }}
      />

      {/* Portal ring */}
      <motion.div
        className="absolute"
        style={{
          width: '400px',
          height: '400px',
          borderRadius: '50%',
          border: `3px solid ${colors.cyan}`,
          boxShadow: `
            0 0 20px ${colors.cyan},
            0 0 40px ${colors.cyan},
            0 0 60px ${colors.cyan},
            inset 0 0 20px ${colors.cyan},
            inset 0 0 40px ${colors.cyan}
          `,
        }}
        initial={{ scale: 0, opacity: 0, rotate: 0 }}
        animate={{
          scale: phase === 'shimmer' ? 0 : phase === 'portal' ? [0, 1.2, 1] : [1, 1.5],
          opacity: phase === 'shimmer' ? 0 : phase === 'portal' ? [0, 1, 1] : [1, 0],
          rotate: phase === 'portal' ? [0, 180] : [180, 360],
        }}
        transition={{
          duration: 2,
          ease: 'easeOut',
        }}
      />

      {/* Inner portal ring */}
      <motion.div
        className="absolute"
        style={{
          width: '300px',
          height: '300px',
          borderRadius: '50%',
          border: `2px solid ${colors.violet}`,
          boxShadow: `
            0 0 15px ${colors.violet},
            0 0 30px ${colors.violet},
            inset 0 0 15px ${colors.violet}
          `,
        }}
        initial={{ scale: 0, opacity: 0, rotate: 0 }}
        animate={{
          scale: phase === 'shimmer' ? 0 : phase === 'portal' ? [0, 1.1, 1] : [1, 1.3],
          opacity: phase === 'shimmer' ? 0 : phase === 'portal' ? [0, 0.8, 0.8] : [0.8, 0],
          rotate: phase === 'portal' ? [0, -120] : [-120, -240],
        }}
        transition={{
          duration: 2,
          ease: 'easeOut',
        }}
      />

      {/* Ripple particles */}
      {[...Array(12)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-2 h-2 rounded-full"
          style={{
            background: i % 3 === 0 ? colors.cyan : i % 3 === 1 ? colors.violet : colors.mint,
            boxShadow: `0 0 10px ${i % 3 === 0 ? colors.cyan : i % 3 === 1 ? colors.violet : colors.mint}`,
          }}
          initial={{
            x: 0,
            y: 0,
            opacity: 0,
          }}
          animate={{
            x: phase === 'portal' || phase === 'dissolve' 
              ? Math.cos((i * 30) * Math.PI / 180) * 200 
              : 0,
            y: phase === 'portal' || phase === 'dissolve'
              ? Math.sin((i * 30) * Math.PI / 180) * 200
              : 0,
            opacity: phase === 'shimmer' ? 0 : phase === 'portal' ? [0, 1, 0.5] : [0.5, 0],
            scale: phase === 'portal' ? [0, 1.5, 1] : [1, 0],
          }}
          transition={{
            duration: 2,
            delay: phase === 'portal' ? i * 0.05 : 0,
            ease: 'easeOut',
          }}
        />
      ))}

      {/* Center shimmer burst */}
      <motion.div
        className="absolute w-40 h-40 rounded-full"
        style={{
          background: `radial-gradient(circle, ${colors.cyan}80, ${colors.violet}40, transparent)`,
          filter: 'blur(30px)',
        }}
        animate={{
          scale: phase === 'shimmer' ? [1, 1.5, 1] : phase === 'portal' ? [1, 2, 1.5] : [1.5, 3],
          opacity: phase === 'shimmer' ? [0.5, 0.8, 0.5] : phase === 'portal' ? [0.8, 1] : [1, 0],
        }}
        transition={{
          duration: phase === 'shimmer' ? 2 : 2,
          ease: 'easeInOut',
          repeat: phase === 'shimmer' ? Infinity : 0,
        }}
      />

      {/* Logo text */}
      <motion.div
        className="absolute text-center"
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{
          opacity: phase === 'shimmer' ? [0, 1, 1] : phase === 'portal' ? 1 : [1, 0],
          scale: phase === 'shimmer' ? [0.8, 1] : phase === 'portal' ? 1 : [1, 1.2],
          y: phase === 'dissolve' ? -50 : 0,
        }}
        transition={{
          duration: 2,
          ease: 'easeOut',
        }}
      >
        <h1
          style={{
            fontFamily: "'Michroma', sans-serif",
            fontSize: '3rem',
            color: colors.cyan,
            textShadow: `
              0 0 20px ${colors.cyan},
              0 0 40px ${colors.cyan},
              0 0 60px ${colors.cyan},
              0 0 80px ${colors.cyan}
            `,
            letterSpacing: '0.2em',
          }}
        >
          NARRATIVEFORGE
        </h1>
        <motion.p
          style={{
            fontFamily: "'Michroma', sans-serif",
            fontSize: '0.8rem',
            color: colors.textLo,
            letterSpacing: '0.15em',
            marginTop: '1rem',
          }}
          animate={{
            opacity: phase === 'portal' ? [0, 1] : 1,
          }}
        >
          INITIALIZING...
        </motion.p>
      </motion.div>

      {/* Liquid distortion overlay */}
      <motion.div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: `
            repeating-linear-gradient(
              0deg,
              transparent,
              ${colors.cyan}10 2px,
              transparent 4px
            )
          `,
          mixBlendMode: 'screen',
        }}
        animate={{
          opacity: phase === 'dissolve' ? [0.3, 0] : 0.3,
          y: phase === 'dissolve' ? [0, 100] : 0,
        }}
        transition={{
          duration: 2,
          ease: 'easeIn',
        }}
      />
    </motion.div>
  );
};

export default ShimmerPortal;

