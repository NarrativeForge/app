import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { TronButton } from '../ui';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, Copy, Download, Save } from 'lucide-react';

function TextMediaGenerator() {
  const [activeTab, setActiveTab] = useState('text');
  const [textMode, setTextMode] = useState('story');
  const [prompt, setPrompt] = useState('');
  const [length, setLength] = useState('medium');
  const [tone, setTone] = useState('neutral');
  const [style, setStyle] = useState('modern');
  const [aspect, setAspect] = useState('1:1');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      setError('Please enter a prompt');
      return;
    }

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      let endpoint = '';
      let body = {};

      if (activeTab === 'text') {
        endpoint = '/api/gen/text';
        body = { mode: textMode, prompt, length, tone, style };
      } else if (activeTab === 'image') {
        endpoint = '/api/gen/image';
        body = { prompt, aspect };
      } else if (activeTab === 'video') {
        endpoint = '/api/gen/image-to-video';
        body = { prompt };
      }

      const response = await fetch(`${endpoint}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });

      const data = await response.json();
      
      if (response.ok) {
        setResult(data);
      } else {
        setError(data.error || 'Generation failed');
      }
    } catch (err) {
      setError('Failed to connect to server');
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    if (result?.text) {
      navigator.clipboard.writeText(result.text);
    }
  };

  const handleDownload = () => {
    if (result?.url) {
      window.open(result.url, '_blank');
    } else if (result?.text) {
      const blob = new Blob([result.text], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${textMode}-${Date.now()}.txt`;
      a.click();
    }
  };

  const handleSave = () => {
    // Save to local storage or backend
    const saved = JSON.parse(localStorage.getItem('saved') || '[]');
    saved.push({ ...result, timestamp: Date.now(), type: activeTab });
    localStorage.setItem('saved', JSON.stringify(saved));
    alert('Saved successfully!');
  };

  return (
    <div className="bg-black/40 backdrop-blur-xl border border-cyan-500/30 rounded-2xl p-8 shadow-2xl">
      <h2 
        className="text-3xl font-bold mb-6 text-center uppercase"
        style={{
          fontFamily: "'Michroma', sans-serif",
          color: '#36d2ff',
          textShadow: '0 0 10px #36d2ff, 0 0 20px #36d2ff, 0 0 30px #36d2ff, 0 0 40px #36d2ff',
          letterSpacing: '0.15em',
        }}
      >
        Forge Your Vision
      </h2>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3 mb-6 bg-gray-900/50">
          <TabsTrigger 
            value="text" 
            className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400"
            style={activeTab === 'text' ? { textShadow: '0 0 10px #36d2ff, 0 0 20px #36d2ff' } : {}}
          >
            Text
          </TabsTrigger>
          <TabsTrigger 
            value="image" 
            className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400"
            style={activeTab === 'image' ? { textShadow: '0 0 10px #36d2ff, 0 0 20px #36d2ff' } : {}}
          >
            Image
          </TabsTrigger>
          <TabsTrigger 
            value="video" 
            className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400"
            style={activeTab === 'video' ? { textShadow: '0 0 10px #36d2ff, 0 0 20px #36d2ff' } : {}}
          >
            Image → Video
          </TabsTrigger>
        </TabsList>

        <TabsContent value="text" className="space-y-6">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 mb-4">
            {['story', 'screenplay', 'poem', 'song', 'rap', 'speech'].map((mode) => (
              <TronButton
                key={mode}
                active={textMode === mode}
                onClick={() => setTextMode(mode)}
              >
                {mode}
              </TronButton>
            ))}
          </div>

          <Textarea
            placeholder="Enter your prompt here..."
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="min-h-[150px] bg-gray-900/50 border-cyan-500/30 text-white placeholder:text-gray-500"
          />

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label 
                className="text-sm text-cyan-400 mb-2 block uppercase"
                style={{ 
                  textShadow: '0 0 5px #36d2ff, 0 0 10px #36d2ff',
                  letterSpacing: '0.1em',
                }}
              >
                Length
              </label>
              <Select value={length} onValueChange={setLength}>
                <SelectTrigger className="bg-gray-900/50 border-cyan-500/30">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="short">Short</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="long">Long</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label 
                className="text-sm text-cyan-400 mb-2 block uppercase"
                style={{ 
                  textShadow: '0 0 5px #36d2ff, 0 0 10px #36d2ff',
                  letterSpacing: '0.1em',
                }}
              >
                Tone
              </label>
              <Select value={tone} onValueChange={setTone}>
                <SelectTrigger className="bg-gray-900/50 border-cyan-500/30">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="neutral">Neutral</SelectItem>
                  <SelectItem value="formal">Formal</SelectItem>
                  <SelectItem value="casual">Casual</SelectItem>
                  <SelectItem value="dramatic">Dramatic</SelectItem>
                  <SelectItem value="humorous">Humorous</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label 
                className="text-sm text-cyan-400 mb-2 block uppercase"
                style={{ 
                  textShadow: '0 0 5px #36d2ff, 0 0 10px #36d2ff',
                  letterSpacing: '0.1em',
                }}
              >
                Style
              </label>
              <Select value={style} onValueChange={setStyle}>
                <SelectTrigger className="bg-gray-900/50 border-cyan-500/30">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="modern">Modern</SelectItem>
                  <SelectItem value="classic">Classic</SelectItem>
                  <SelectItem value="poetic">Poetic</SelectItem>
                  <SelectItem value="minimalist">Minimalist</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="image" className="space-y-6">
          <Textarea
            placeholder="Describe the image you want to generate..."
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="min-h-[150px] bg-gray-900/50 border-cyan-500/30 text-white placeholder:text-gray-500"
          />

          <div>
            <label className="text-sm text-cyan-400 mb-2 block">Aspect Ratio</label>
            <Select value={aspect} onValueChange={setAspect}>
              <SelectTrigger className="bg-gray-900/50 border-cyan-500/30">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1:1">Square (1:1)</SelectItem>
                <SelectItem value="16:9">Landscape (16:9)</SelectItem>
                <SelectItem value="9:16">Portrait (9:16)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </TabsContent>

        <TabsContent value="video" className="space-y-6">
          <Textarea
            placeholder="Describe the video motion or provide an image URL..."
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="min-h-[150px] bg-gray-900/50 border-cyan-500/30 text-white placeholder:text-gray-500"
          />
        </TabsContent>

        <Button
          onClick={handleGenerate}
          disabled={loading}
          className="w-full bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-600 hover:to-purple-700 text-white font-semibold py-6 text-lg uppercase"
          style={{
            textShadow: '0 0 10px rgba(255,255,255,0.8), 0 0 20px #36d2ff',
            boxShadow: '0 0 20px #36d2ff, 0 0 40px #a66bff, 0 4px 12px rgba(0,0,0,0.5)',
            letterSpacing: '0.1em',
          }}
        >
          {loading ? (
            <>
              <Loader2 className="mr-2 h-5 w-5 animate-spin" />
              Generating...
            </>
          ) : (
            'Generate'
          )}
        </Button>
      </Tabs>

      {/* Error display */}
      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="mt-6 p-4 bg-red-500/20 border border-red-500/50 rounded-lg text-red-400"
          >
            {error}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Result display */}
      <AnimatePresence>
        {result && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="mt-6"
          >
            <Card className="bg-gray-900/50 border-cyan-500/30">
              <CardHeader>
                <CardTitle className="text-cyan-400">Result</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {result.text && (
                  <div className="p-4 bg-black/30 rounded-lg text-white whitespace-pre-wrap">
                    {result.text}
                  </div>
                )}
                {result.url && (
                  <div className="flex justify-center">
                    {activeTab === 'image' ? (
                      <img src={result.url} alt="Generated" className="max-w-full rounded-lg" />
                    ) : (
                      <video src={result.url} controls className="max-w-full rounded-lg" />
                    )}
                  </div>
                )}
                <div className="flex gap-3">
                  {result.text && (
                    <Button onClick={handleCopy} variant="outline" className="border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/20">
                      <Copy className="mr-2 h-4 w-4" />
                      Copy
                    </Button>
                  )}
                  <Button onClick={handleDownload} variant="outline" className="border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/20">
                    <Download className="mr-2 h-4 w-4" />
                    Download
                  </Button>
                  <Button onClick={handleSave} variant="outline" className="border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/20">
                    <Save className="mr-2 h-4 w-4" />
                    Save
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default TextMediaGenerator;

