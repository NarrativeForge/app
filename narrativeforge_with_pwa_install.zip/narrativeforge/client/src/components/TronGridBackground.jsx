
import React from 'react';
import { motion } from 'framer-motion';

const TronGridBackground = () => {
  return (
    <div className="fixed inset-0 z-0 overflow-hidden pointer-events-none">
      {/* Layer 1: Circuitry background - slow drift */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 3 }}
        className="absolute inset-0 circuitry-bg"
      />
      
      {/* Layer 2: Tron grid - pulsing and drifting */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 2, delay: 0.5 }}
        className="absolute inset-0 tron-grid"
      />
      
      {/* Layer 3: Gradient overlay */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.2 }}
        transition={{ duration: 3, delay: 1 }}
        className="absolute inset-0 bg-gradient-to-br from-cyan-900/20 via-transparent to-purple-900/20"
      />
    </div>
  );
};

export default TronGridBackground;

