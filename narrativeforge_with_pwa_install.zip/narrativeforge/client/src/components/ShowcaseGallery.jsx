import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { colors } from '../tokens';

const showcaseItems = [
  {
    type: 'image',
    title: 'CYBERPUNK_WARRIOR',
    category: 'IMG_GEN',
    id: 'NF-2847',
    preview: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=400&h=400&fit=crop',
  },
  {
    type: 'text',
    title: 'MIDNIGHT_SONNET',
    category: 'TXT_POETRY',
    id: 'NF-1923',
    content: '"In circuits deep where data streams flow,\nA consciousness begins to grow..."',
  },
  {
    type: 'image',
    title: 'PIXAR_HERO',
    category: 'IMG_CHAR',
    id: 'NF-5612',
    preview: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?w=400&h=400&fit=crop',
  },
  {
    type: 'text',
    title: 'SCI_FI_SCREENPLAY',
    category: 'TXT_SCRIPT',
    id: 'NF-7834',
    content: 'INT. SPACE_STATION - NIGHT\n> The hologram flickers to life...',
  },
  {
    type: 'image',
    title: 'FANTASY_LANDSCAPE',
    category: 'IMG_SCENE',
    id: 'NF-4201',
    preview: 'https://images.unsplash.com/photo-1579546929518-9e396f3cc809?w=400&h=400&fit=crop',
  },
];

const ShowcaseGallery = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isCollapsed, setIsCollapsed] = useState(false);

  useEffect(() => {
    if (!isCollapsed) {
      const interval = setInterval(() => {
        setCurrentIndex((prev) => (prev + 1) % showcaseItems.length);
      }, 4000);

      return () => clearInterval(interval);
    }
  }, [isCollapsed]);

  const currentItem = showcaseItems[currentIndex];

  return (
    <div className="w-full py-6 relative">
      <div className="max-w-5xl mx-auto px-6">
        {/* HUD-style header with collapse toggle */}
        <div className="flex items-center gap-3 mb-4">
          <motion.div
            className="w-2 h-2 rounded-full"
            style={{
              background: colors.cyan,
              boxShadow: `0 0 10px ${colors.cyan}`,
            }}
            animate={{
              opacity: [0.5, 1, 0.5],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
          />
          <div
            className="text-xs uppercase tracking-widest"
            style={{
              fontFamily: "'Michroma', sans-serif",
              color: colors.cyan,
              textShadow: `0 0 5px ${colors.cyan}`,
              letterSpacing: '0.15em',
            }}
          >
            RECENT_OUTPUTS // SYSTEM_SHOWCASE
          </div>
          <div className="flex-1 h-px" style={{ background: `linear-gradient(to right, ${colors.cyan}40, transparent)` }} />
          
          {/* Collapse/Expand Toggle Button */}
          <motion.button
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="relative px-3 py-1.5 border rounded text-xs uppercase tracking-wider"
            style={{
              fontFamily: "'Michroma', sans-serif",
              background: 'rgba(0, 0, 0, 0.5)',
              borderColor: colors.cyan,
              color: colors.cyan,
              fontSize: '0.65rem',
            }}
            whileHover={{
              boxShadow: `0 0 15px ${colors.glowCyan}`,
              borderColor: colors.cyan,
            }}
            whileTap={{ scale: 0.95 }}
            transition={{ duration: 0.16 }}
          >
            {/* Corner brackets */}
            {[
              { top: -1, left: -1, rotate: 0 },
              { top: -1, right: -1, rotate: 90 },
              { bottom: -1, right: -1, rotate: 180 },
              { bottom: -1, left: -1, rotate: 270 },
            ].map((pos, i) => (
              <div
                key={i}
                className="absolute w-1.5 h-1.5 pointer-events-none"
                style={{
                  ...pos,
                  borderTop: `1px solid ${colors.cyan}`,
                  borderLeft: `1px solid ${colors.cyan}`,
                  transform: `rotate(${pos.rotate}deg)`,
                }}
              />
            ))}
            
            <div className="flex items-center gap-2">
              <motion.div
                animate={{ rotate: isCollapsed ? 0 : 180 }}
                transition={{ duration: 0.3 }}
              >
                ▼
              </motion.div>
              <span>{isCollapsed ? 'EXPAND' : 'COLLAPSE'}</span>
            </div>
          </motion.button>
        </div>

        {/* Collapsible content */}
        <AnimatePresence>
          {!isCollapsed && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.4, ease: 'easeInOut' }}
              style={{ overflow: 'hidden' }}
            >
              {/* Main display panel - Minority Report style */}
              <div className="relative">
                {/* Grid background */}
                <div
                  className="absolute inset-0 opacity-20 pointer-events-none"
                  style={{
                    backgroundImage: `
                      linear-gradient(${colors.cyan}20 1px, transparent 1px),
                      linear-gradient(90deg, ${colors.cyan}20 1px, transparent 1px)
                    `,
                    backgroundSize: '20px 20px',
                  }}
                />

                <div className="grid grid-cols-3 gap-4 relative">
                  {/* Left panel - Thumbnails */}
                  <div className="space-y-2">
                    {showcaseItems.map((item, index) => (
                      <motion.button
                        key={index}
                        onClick={() => setCurrentIndex(index)}
                        className="w-full text-left p-2 border rounded relative overflow-hidden"
                        style={{
                          background: index === currentIndex ? `${colors.cyan}10` : 'rgba(0, 0, 0, 0.3)',
                          borderColor: index === currentIndex ? colors.cyan : `${colors.cyan}20`,
                          boxShadow: index === currentIndex ? `0 0 15px ${colors.glowCyan}` : 'none',
                        }}
                        whileHover={{
                          borderColor: colors.cyan,
                          boxShadow: `0 0 10px ${colors.glowCyan}`,
                        }}
                        transition={{ duration: 0.16 }}
                      >
                        {/* Scan line effect */}
                        {index === currentIndex && (
                          <motion.div
                            className="absolute inset-0 h-full"
                            style={{
                              background: `linear-gradient(to bottom, transparent, ${colors.cyan}20, transparent)`,
                            }}
                            animate={{
                              y: ['-100%', '200%'],
                            }}
                            transition={{
                              duration: 2,
                              repeat: Infinity,
                              ease: 'linear',
                            }}
                          />
                        )}
                        
                        <div
                          className="text-xs font-mono mb-1"
                          style={{
                            color: index === currentIndex ? colors.cyan : colors.textLo,
                            textShadow: index === currentIndex ? `0 0 5px ${colors.cyan}` : 'none',
                          }}
                        >
                          {item.id}
                        </div>
                        <div
                          className="text-xs"
                          style={{
                            fontFamily: "'Michroma', sans-serif",
                            color: index === currentIndex ? colors.textHi : colors.textLo,
                            fontSize: '0.65rem',
                          }}
                        >
                          {item.category}
                        </div>
                      </motion.button>
                    ))}
                  </div>

                  {/* Center panel - Main display */}
                  <div className="col-span-2 relative">
                    <AnimatePresence mode="wait">
                      <motion.div
                        key={currentIndex}
                        className="border rounded-lg overflow-hidden relative"
                        style={{
                          background: 'rgba(0, 0, 0, 0.5)',
                          borderColor: colors.cyan,
                          boxShadow: `0 0 30px ${colors.glowCyan}, inset 0 0 20px ${colors.glowCyan}20`,
                        }}
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        transition={{ duration: 0.4, ease: 'easeOut' }}
                      >
                        {/* Shimmer portal effect overlay on transition */}
                        <motion.div
                          className="absolute inset-0 pointer-events-none z-20"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: [0, 0.6, 0] }}
                          transition={{ duration: 0.8, ease: 'easeInOut' }}
                        >
                          {/* Ripple rings */}
                          {[...Array(3)].map((_, i) => (
                            <motion.div
                              key={`ripple-${i}`}
                              className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full border-2"
                              style={{
                                borderColor: i % 2 === 0 ? colors.cyan : colors.violet,
                                boxShadow: `0 0 15px ${i % 2 === 0 ? colors.cyan : colors.violet}`,
                              }}
                              initial={{ width: 0, height: 0, opacity: 0 }}
                              animate={{
                                width: ['0px', '300px', '500px'],
                                height: ['0px', '300px', '500px'],
                                opacity: [0, 0.6, 0],
                              }}
                              transition={{
                                duration: 0.8,
                                delay: i * 0.1,
                                ease: 'easeOut',
                              }}
                            />
                          ))}
                          {/* Shimmer wave */}
                          <motion.div
                            className="absolute inset-0"
                            style={{
                              background: `radial-gradient(circle at 50% 50%, ${colors.cyan}40, transparent 60%)`,
                              filter: 'blur(30px)',
                            }}
                            initial={{ scale: 0, opacity: 0 }}
                            animate={{
                              scale: [0, 1.5, 2],
                              opacity: [0, 0.8, 0],
                            }}
                            transition={{
                              duration: 0.8,
                              ease: 'easeOut',
                            }}
                          />
                        </motion.div>
                        {/* Shimmer edge glow */}
                        <motion.div
                          className="absolute inset-0 pointer-events-none"
                          style={{
                            boxShadow: `inset 0 0 40px ${colors.glowCyan}`,
                          }}
                          animate={{
                            opacity: [0.3, 0.6, 0.3],
                          }}
                          transition={{
                            duration: 2,
                            repeat: Infinity,
                            ease: 'easeInOut',
                          }}
                        />

                        {/* Corner brackets - Minority Report style */}
                        {[
                          { top: 0, left: 0, rotate: 0 },
                          { top: 0, right: 0, rotate: 90 },
                          { bottom: 0, right: 0, rotate: 180 },
                          { bottom: 0, left: 0, rotate: 270 },
                        ].map((pos, i) => (
                          <div
                            key={i}
                            className="absolute w-4 h-4"
                            style={{
                              ...pos,
                              borderTop: `2px solid ${colors.cyan}`,
                              borderLeft: `2px solid ${colors.cyan}`,
                              transform: `rotate(${pos.rotate}deg)`,
                              boxShadow: `0 0 5px ${colors.cyan}`,
                            }}
                          />
                        ))}

                        {/* Header bar */}
                        <div
                          className="p-3 border-b flex items-center justify-between"
                          style={{
                            background: `${colors.cyan}05`,
                            borderColor: `${colors.cyan}30`,
                          }}
                        >
                          <div>
                            <div
                              className="text-xs font-mono"
                              style={{
                                color: colors.cyan,
                                textShadow: `0 0 5px ${colors.cyan}`,
                              }}
                            >
                              {currentItem.id}
                            </div>
                            <div
                              className="text-sm mt-1"
                              style={{
                                fontFamily: "'Michroma', sans-serif",
                                color: colors.textHi,
                                textShadow: `0 0 8px ${colors.cyan}`,
                                letterSpacing: '0.1em',
                              }}
                            >
                              {currentItem.title}
                            </div>
                          </div>
                          <div
                            className="px-3 py-1 border rounded text-xs"
                            style={{
                              borderColor: colors.cyan,
                              color: colors.cyan,
                              fontFamily: "'Michroma', sans-serif",
                              fontSize: '0.65rem',
                              boxShadow: `0 0 10px ${colors.glowCyan}`,
                            }}
                          >
                            {currentItem.category}
                          </div>
                        </div>

                        {/* Content area */}
                        <div className="p-4">
                          {currentItem.type === 'image' && currentItem.preview ? (
                            <div className="relative rounded overflow-hidden">
                              <img
                                src={currentItem.preview}
                                alt={currentItem.title}
                                className="w-full h-48 object-cover"
                                style={{
                                  opacity: 0.4,
                                  filter: 'brightness(1.2) contrast(1.3) saturate(0.8)',
                                  mixBlendMode: 'screen',
                                }}
                              />
                              {/* Holographic cyan tint overlay */}
                              <div
                                className="absolute inset-0"
                                style={{
                                  background: `linear-gradient(135deg, ${colors.cyan}30, ${colors.violet}20, ${colors.mint}30)`,
                                  mixBlendMode: 'color',
                                  opacity: 0.8,
                                }}
                              />
                              {/* Scan lines - horizontal */}
                              <div
                                className="absolute inset-0 pointer-events-none"
                                style={{
                                  background: `repeating-linear-gradient(0deg, transparent, ${colors.cyan}15 1px, transparent 2px)`,
                                }}
                              />
                              {/* Vertical scan lines */}
                              <div
                                className="absolute inset-0 pointer-events-none"
                                style={{
                                  background: `repeating-linear-gradient(90deg, transparent, ${colors.cyan}08 1px, transparent 3px)`,
                                }}
                              />
                              {/* Holographic shimmer */}
                              <motion.div
                                className="absolute inset-0 pointer-events-none"
                                style={{
                                  background: `linear-gradient(45deg, transparent 30%, ${colors.cyan}20 50%, transparent 70%)`,
                                }}
                                animate={{
                                  x: ['-100%', '200%'],
                                }}
                                transition={{
                                  duration: 3,
                                  repeat: Infinity,
                                  ease: 'linear',
                                }}
                              />
                              {/* Edge glow */}
                              <div
                                className="absolute inset-0 pointer-events-none"
                                style={{
                                  boxShadow: `inset 0 0 30px ${colors.cyan}40`,
                                }}
                              />
                            </div>
                          ) : (
                            <div
                              className="p-4 rounded font-mono text-sm h-48 flex items-center"
                              style={{
                                background: 'rgba(0, 0, 0, 0.5)',
                                color: colors.textHi,
                                borderLeft: `3px solid ${colors.cyan}`,
                                whiteSpace: 'pre-line',
                              }}
                            >
                              {currentItem.content}
                            </div>
                          )}
                        </div>

                        {/* Status bar */}
                        <div
                          className="px-4 py-2 border-t flex items-center justify-between text-xs font-mono"
                          style={{
                            background: `${colors.cyan}05`,
                            borderColor: `${colors.cyan}30`,
                            color: colors.textLo,
                          }}
                        >
                          <div>STATUS: ACTIVE</div>
                          <div className="flex items-center gap-2">
                            <motion.div
                              className="w-1.5 h-1.5 rounded-full"
                              style={{ background: colors.cyan }}
                              animate={{ opacity: [0.5, 1, 0.5] }}
                              transition={{ duration: 1.5, repeat: Infinity }}
                            />
                            <span>RENDERING</span>
                          </div>
                        </div>
                      </motion.div>
                    </AnimatePresence>
                  </div>
                </div>

                {/* Progress indicator */}
                <div className="mt-4 flex items-center gap-2">
                  <div className="flex-1 h-px bg-black/50 rounded-full overflow-hidden">
                    <motion.div
                      className="h-full"
                      style={{
                        background: `linear-gradient(to right, ${colors.cyan}, ${colors.violet})`,
                        boxShadow: `0 0 10px ${colors.cyan}`,
                      }}
                      initial={{ width: '0%' }}
                      animate={{ width: '100%' }}
                      transition={{
                        duration: 4,
                        repeat: Infinity,
                        ease: 'linear',
                      }}
                    />
                  </div>
                  <div
                    className="text-xs font-mono"
                    style={{
                      color: colors.cyan,
                      fontFamily: "'Michroma', sans-serif",
                      fontSize: '0.65rem',
                    }}
                  >
                    {currentIndex + 1}/{showcaseItems.length}
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default ShowcaseGallery;

