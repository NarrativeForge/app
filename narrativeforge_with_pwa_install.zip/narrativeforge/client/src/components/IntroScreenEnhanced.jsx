import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

function IntroScreenEnhanced({ onComplete }) {
  const [showControls, setShowControls] = useState(false);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const videoRef = useRef(null);
  const canvasRef = useRef(null);

  useEffect(() => {
    const videoElement = videoRef.current;

    const handleVideoEnd = () => {
      setShowControls(true);
    };

    if (videoElement) {
      videoElement.addEventListener('ended', handleVideoEnd);
      videoElement.play().catch(error => {
        console.log('Autoplay prevented:', error);
        setShowControls(true);
      });
    }

    const timer = setTimeout(() => {
      setShowControls(true);
    }, 3000);

    // Initialize Tron grid animation on canvas
    const canvas = canvasRef.current;
    if (canvas) {
      const ctx = canvas.getContext('2d');
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;

      let animationId;
      let gridOffset = 0;

      const drawTronGrid = () => {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        // Draw grid lines with cyan glow
        ctx.strokeStyle = 'rgba(0, 255, 255, 0.15)';
        ctx.lineWidth = 1;
        ctx.shadowBlur = 10;
        ctx.shadowColor = 'rgba(0, 255, 255, 0.5)';

        const gridSize = 50;
        
        // Vertical lines
        for (let x = 0; x < canvas.width; x += gridSize) {
          ctx.beginPath();
          ctx.moveTo(x + gridOffset, 0);
          ctx.lineTo(x + gridOffset, canvas.height);
          ctx.stroke();
        }

        // Horizontal lines
        for (let y = 0; y < canvas.height; y += gridSize) {
          ctx.beginPath();
          ctx.moveTo(0, y + gridOffset);
          ctx.lineTo(canvas.width, y + gridOffset);
          ctx.stroke();
        }

        gridOffset = (gridOffset + 0.5) % gridSize;
        animationId = requestAnimationFrame(drawTronGrid);
      };

      drawTronGrid();

      return () => {
        clearTimeout(timer);
        cancelAnimationFrame(animationId);
        if (videoElement) {
          videoElement.removeEventListener('ended', handleVideoEnd);
        }
      };
    }

    return () => {
      clearTimeout(timer);
      if (videoElement) {
        videoElement.removeEventListener('ended', handleVideoEnd);
      }
    };
  }, []);

  const handleEnter = () => {
    if (videoRef.current) {
      videoRef.current.pause();
    }
    setIsTransitioning(true);
    
    // Trigger haptic feedback if available
    if (navigator.vibrate) {
      navigator.vibrate(50);
    }

    // Wait for wormhole animation to complete
    setTimeout(() => {
      onComplete();
    }, 1500);
  };

  return (
    <>
      <motion.div
        initial={{ opacity: 1 }}
        exit={{ opacity: 0, scale: 0.5, transition: { duration: 1.5 } }}
        className="fixed inset-0 bg-black flex items-center justify-center overflow-hidden z-50"
        style={{ fontFamily: "'Orbitron', sans-serif" }}
      >
        {/* Tron Grid Background Canvas */}
        <canvas
          ref={canvasRef}
          className="absolute inset-0 opacity-30 pointer-events-none"
        />

        {/* Video Background */}
        <video
          ref={videoRef}
          src="/intro.mp4"
          className="absolute inset-0 w-full h-full object-cover"
          style={{
            objectFit: 'cover',
            width: '100vw',
            height: '100vh'
          }}
          muted
          playsInline
          preload="auto"
        />

        {/* Overlay gradient for better text visibility */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black/60 pointer-events-none" />

        {/* Minimal Enter Button */}
        <AnimatePresence>
          {showControls && !isTransitioning && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 1 }}
              className="absolute bottom-12 left-0 right-0 flex justify-center z-10"
            >
              <motion.button
                onClick={handleEnter}
                className="relative px-8 py-3 text-cyan-400 text-sm tracking-[0.3em] uppercase backdrop-blur-md bg-black/20 rounded-full border border-cyan-400/30 hover:border-cyan-400/60 hover:text-cyan-300 transition-all duration-300 overflow-hidden group"
                whileHover={{ scale: 1.05, boxShadow: '0 0 20px rgba(0, 255, 255, 0.3)' }}
                whileTap={{ scale: 0.95 }}
              >
                <span className="relative z-10">Enter the Forge</span>
                <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-cyan-500/20 to-purple-500/20"
                  initial={{ x: '-100%' }}
                  whileHover={{ x: '100%' }}
                  transition={{ duration: 0.6 }}
                />
              </motion.button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Wormhole Transition Effect */}
        <AnimatePresence>
          {isTransitioning && (
            <motion.div
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 50, opacity: 1 }}
              transition={{ duration: 1.5, ease: [0.43, 0.13, 0.23, 0.96] }}
              className="absolute inset-0 flex items-center justify-center pointer-events-none"
            >
              <div className="w-32 h-32 rounded-full bg-gradient-to-r from-cyan-500 via-purple-500 to-pink-500 blur-xl animate-spin" />
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* Add Orbitron font */}
      <link
        href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;600;700;800;900&display=swap"
        rel="stylesheet"
      />
    </>
  );
}

export default IntroScreenEnhanced;

