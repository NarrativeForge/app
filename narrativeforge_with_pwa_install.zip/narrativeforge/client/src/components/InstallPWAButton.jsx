import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Download, X, Smartphone, Monitor, Share } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { colors } from '../tokens';

const InstallPWAButton = () => {
  const { isInstallable, isInstalled, isIOS, isStandalone, installPWA, canInstall } = usePWAInstall();
  const [showIOSInstructions, setShowIOSInstructions] = useState(false);

  // Don't show button if already installed
  if (isInstalled || isStandalone) {
    return null;
  }

  const handleInstallClick = async () => {
    if (isIOS) {
      setShowIOSInstructions(true);
    } else if (canInstall) {
      await installPWA();
    }
  };

  return (
    <>
      {/* Install Button */}
      <motion.button
        onClick={handleInstallClick}
        className="relative px-4 py-2 border rounded-lg text-sm uppercase tracking-wider overflow-hidden"
        style={{
          fontFamily: "'Michroma', sans-serif",
          background: 'rgba(0, 0, 0, 0.5)',
          borderColor: colors.cyan,
          color: colors.cyan,
          fontSize: '0.75rem',
        }}
        whileHover={{
          boxShadow: `0 0 20px ${colors.glowCyan}`,
          borderColor: colors.cyan,
        }}
        whileTap={{ scale: 0.95 }}
        transition={{ duration: 0.16 }}
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.9 }}
      >
        {/* Corner brackets */}
        {[
          { top: -1, left: -1, rotate: 0 },
          { top: -1, right: -1, rotate: 90 },
          { bottom: -1, right: -1, rotate: 180 },
          { bottom: -1, left: -1, rotate: 270 },
        ].map((pos, i) => (
          <div
            key={i}
            className="absolute w-2 h-2 pointer-events-none"
            style={{
              ...pos,
              borderTop: `2px solid ${colors.cyan}`,
              borderLeft: `2px solid ${colors.cyan}`,
              transform: `rotate(${pos.rotate}deg)`,
            }}
          />
        ))}

        {/* Glow effect */}
        <motion.div
          className="absolute inset-0 pointer-events-none"
          style={{
            background: `radial-gradient(circle at center, ${colors.cyan}20, transparent 70%)`,
          }}
          animate={{
            opacity: [0.3, 0.6, 0.3],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        />

        <div className="flex items-center gap-2 relative z-10">
          <Download size={16} />
          <span>Install App</span>
        </div>
      </motion.button>

      {/* iOS Instructions Modal */}
      <AnimatePresence>
        {showIOSInstructions && (
          <motion.div
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
            style={{ background: 'rgba(0, 0, 0, 0.8)' }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowIOSInstructions(false)}
          >
            <motion.div
              className="relative max-w-md w-full p-6 rounded-xl border"
              style={{
                background: 'rgba(11, 22, 32, 0.95)',
                borderColor: colors.cyan,
                boxShadow: `0 0 40px ${colors.glowCyan}`,
              }}
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
            >
              {/* Close button */}
              <button
                onClick={() => setShowIOSInstructions(false)}
                className="absolute top-4 right-4 p-2 rounded-lg"
                style={{
                  color: colors.textLo,
                  background: 'rgba(255, 255, 255, 0.1)',
                }}
              >
                <X size={20} />
              </button>

              {/* Header */}
              <div className="flex items-center gap-3 mb-6">
                <Smartphone
                  size={32}
                  style={{ color: colors.cyan }}
                />
                <h3
                  className="text-xl font-bold"
                  style={{
                    fontFamily: "'Michroma', sans-serif",
                    color: colors.cyan,
                    textShadow: `0 0 10px ${colors.cyan}`,
                  }}
                >
                  Install on iOS
                </h3>
              </div>

              {/* Instructions */}
              <div
                className="space-y-4 mb-6"
                style={{ color: colors.textHi }}
              >
                <p className="text-sm" style={{ color: colors.textLo }}>
                  To install NarrativeForge on your iPhone or iPad:
                </p>

                <ol className="space-y-3 text-sm">
                  <li className="flex items-start gap-3">
                    <span
                      className="flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold"
                      style={{
                        background: colors.cyan,
                        color: 'black',
                      }}
                    >
                      1
                    </span>
                    <span>
                      Tap the <Share size={16} className="inline mx-1" style={{ color: colors.cyan }} /> 
                      <strong style={{ color: colors.cyan }}>Share</strong> button at the bottom of Safari
                    </span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span
                      className="flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold"
                      style={{
                        background: colors.cyan,
                        color: 'black',
                      }}
                    >
                      2
                    </span>
                    <span>
                      Scroll down and tap <strong style={{ color: colors.cyan }}>"Add to Home Screen"</strong>
                    </span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span
                      className="flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold"
                      style={{
                        background: colors.cyan,
                        color: 'black',
                      }}
                    >
                      3
                    </span>
                    <span>
                      Tap <strong style={{ color: colors.cyan }}>"Add"</strong> in the top right corner
                    </span>
                  </li>
                </ol>

                <div
                  className="p-3 rounded-lg border text-xs"
                  style={{
                    background: `${colors.cyan}10`,
                    borderColor: `${colors.cyan}30`,
                    color: colors.textLo,
                  }}
                >
                  <strong style={{ color: colors.cyan }}>Note:</strong> This feature only works in Safari browser on iOS devices.
                </div>
              </div>

              {/* Close button */}
              <button
                onClick={() => setShowIOSInstructions(false)}
                className="w-full py-3 rounded-lg border text-sm font-semibold uppercase tracking-wider"
                style={{
                  fontFamily: "'Michroma', sans-serif",
                  background: `linear-gradient(135deg, ${colors.cyan}, ${colors.violet})`,
                  borderColor: colors.cyan,
                  color: 'white',
                  boxShadow: `0 0 20px ${colors.glowCyan}`,
                }}
              >
                Got It
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default InstallPWAButton;

