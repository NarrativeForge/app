import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';

function IntroScreen({ onComplete }) {
  const [showControls, setShowControls] = useState(false);
  const [isPlaying, setIsPlaying] = useState(true);
  const videoRef = useRef(null);

  useEffect(() => {
    const videoElement = videoRef.current;

    const handleVideoEnd = () => {
      onComplete();
    };

    if (videoElement) {
      videoElement.addEventListener('ended', handleVideoEnd);
      videoElement.play().catch(error => {
        console.log('Autoplay prevented:', error);
        // Show controls if autoplay is prevented
        setShowControls(true);
        setIsPlaying(false);
      });
    }

    const timer = setTimeout(() => {
      setShowControls(true);
    }, 3000); // Show controls after 3 seconds

    return () => {
      clearTimeout(timer);
      if (videoElement) {
        videoElement.removeEventListener('ended', handleVideoEnd);
      }
    };
  }, [onComplete]);

  const handleEnter = () => {
    if (videoRef.current) {
      videoRef.current.pause();
    }
    onComplete();
  };

  const handleSkip = () => {
    if (videoRef.current) {
      videoRef.current.pause();
    }
    onComplete();
  };

  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 2, transition: { duration: 1, ease: 'easeOut' } }}
      className="fixed inset-0 bg-black flex items-center justify-center overflow-hidden z-50"
    >
      {/* Video Background */}
      <video
        ref={videoRef}
        src="/intro.mp4"
        className="absolute inset-0 w-full h-full object-cover"
        muted
        playsInline
        preload="auto"
      />

      {/* Overlay for effects and controls */}
      <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center">
        <AnimatePresence>
          {showControls && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.5 }}
              className="relative z-10 text-center space-y-6"
            >
              <h1 className="text-5xl md:text-7xl font-bold bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 bg-clip-text text-transparent drop-shadow-lg">
                NarrativeForge
              </h1>
              <p className="text-cyan-300 text-lg md:text-xl tracking-wider mb-8">
                Forge Your Vision
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  onClick={handleEnter}
                  className="bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-600 hover:to-purple-700 text-white font-semibold py-3 px-8 text-lg rounded-full shadow-lg transition-all duration-300 ease-in-out transform hover:scale-105"
                >
                  Enter
                </Button>
                <Button
                  onClick={handleSkip}
                  variant="outline"
                  className="border-cyan-500 text-cyan-400 hover:bg-cyan-500/20 py-3 px-8 text-lg rounded-full shadow-lg transition-all duration-300 ease-in-out transform hover:scale-105"
                >
                  Skip Intro
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}

export default IntroScreen;

