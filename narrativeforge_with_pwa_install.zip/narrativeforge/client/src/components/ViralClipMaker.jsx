import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Upload, Video, Sparkles, TrendingUp, Download, Share2, X, Play, Pause } from 'lucide-react';
import { Button } from '@/components/ui/button';
const API_BASE_URL = 'http://localhost:8080';

function ViralClipMaker({ theme }) {
  const [uploadedVideo, setUploadedVideo] = useState(null);
  const [videoPreview, setVideoPreview] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResults, setAnalysisResults] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const fileInputRef = useRef(null);
  const videoRef = useRef(null);

  const handleFileSelect = (e) => {
    const file = e.target.files[0];
    if (file && file.type.startsWith('video/')) {
      // Check file size (30 minutes at average bitrate ≈ 500MB max)
      const maxSize = 500 * 1024 * 1024; // 500MB
      if (file.size > maxSize) {
        alert('Video file is too large. Please upload a video under 30 minutes.');
        return;
      }

      setUploadedVideo(file);
      const url = URL.createObjectURL(file);
      setVideoPreview(url);
      setAnalysisResults(null);
    }
  };

  const handleAnalyze = async () => {
    if (!uploadedVideo) return;

    setIsAnalyzing(true);

    try {
      const formData = new FormData();
      formData.append('video', uploadedVideo);

      const response = await fetch(`${API_BASE_URL}/api/viral/analyze`, {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Analysis failed');
      }

      const data = await response.json();
      setAnalysisResults(data);
    } catch (error) {
      console.error('Analysis error:', error);
      alert('Failed to analyze video. Please try again.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const togglePlayPause = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleDownload = () => {
    if (analysisResults && analysisResults.optimizedVideo) {
      const link = document.createElement('a');
      link.href = analysisResults.optimizedVideo;
      link.download = 'viral_clip_optimized.mp4';
      link.click();
    }
  };

  const handleShare = (platform) => {
    // TODO: Implement actual social media sharing
    const shareUrls = {
      tiktok: 'https://www.tiktok.com/upload',
      instagram: 'https://www.instagram.com/',
      youtube: 'https://www.youtube.com/upload',
      twitter: 'https://twitter.com/compose/tweet'
    };

    if (shareUrls[platform]) {
      window.open(shareUrls[platform], '_blank');
    }
  };

  const clearVideo = () => {
    setUploadedVideo(null);
    setVideoPreview(null);
    setAnalysisResults(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className={`w-full max-w-6xl mx-auto p-8 rounded-2xl backdrop-blur-xl border transition-all duration-300 ${
      theme === 'dark'
        ? 'bg-gray-900/40 border-cyan-500/20'
        : 'bg-white/60 border-cyan-600/30'
    }`}>
      {/* Header */}
      <div className="flex items-center gap-3 mb-8">
        <Sparkles className={`w-8 h-8 ${theme === 'dark' ? 'text-cyan-400' : 'text-cyan-600'}`} />
        <h2 className={`text-3xl font-bold ${
          theme === 'dark'
            ? 'bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400'
            : 'bg-gradient-to-r from-cyan-600 via-purple-600 to-pink-600'
        } bg-clip-text text-transparent`} style={{ fontFamily: "'Orbitron', sans-serif" }}>
          Viral Clip Maker
        </h2>
      </div>

      {/* Upload Area */}
      {!uploadedVideo ? (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className={`border-2 border-dashed rounded-xl p-12 text-center cursor-pointer transition-all duration-300 ${
            theme === 'dark'
              ? 'border-cyan-500/30 hover:border-cyan-400/60 hover:bg-cyan-950/20'
              : 'border-cyan-600/40 hover:border-cyan-500/70 hover:bg-cyan-100/30'
          }`}
          onClick={() => fileInputRef.current?.click()}
        >
          <Upload className={`w-16 h-16 mx-auto mb-4 ${theme === 'dark' ? 'text-cyan-400/60' : 'text-cyan-600/60'}`} />
          <h3 className={`text-xl font-semibold mb-2 ${theme === 'dark' ? 'text-cyan-300' : 'text-cyan-700'}`}>
            Upload Your Video
          </h3>
          <p className={`text-sm ${theme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
            Click to browse or drag and drop
          </p>
          <p className={`text-xs mt-2 ${theme === 'dark' ? 'text-gray-500' : 'text-gray-500'}`}>
            MP4, MOV, AVI up to 30 minutes
          </p>
          <input
            ref={fileInputRef}
            type="file"
            accept="video/*"
            onChange={handleFileSelect}
            className="hidden"
          />
        </motion.div>
      ) : (
        <div className="space-y-6">
          {/* Video Preview */}
          <div className="relative rounded-xl overflow-hidden">
            <video
              ref={videoRef}
              src={videoPreview}
              className="w-full max-h-96 object-contain bg-black rounded-xl"
              onPlay={() => setIsPlaying(true)}
              onPause={() => setIsPlaying(false)}
            />
            <div className="absolute bottom-4 left-4 right-4 flex items-center gap-3">
              <Button
                onClick={togglePlayPause}
                className={`${theme === 'dark' ? 'bg-cyan-500/80' : 'bg-cyan-600/80'} hover:bg-cyan-400`}
              >
                {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
              </Button>
              <Button
                onClick={clearVideo}
                variant="ghost"
                className={`${theme === 'dark' ? 'text-white bg-red-500/80' : 'text-white bg-red-600/80'} hover:bg-red-400`}
              >
                <X className="w-5 h-5" />
              </Button>
            </div>
          </div>

          {/* Analyze Button */}
          {!analysisResults && (
            <Button
              onClick={handleAnalyze}
              disabled={isAnalyzing}
              className={`w-full py-6 text-lg font-semibold ${
                theme === 'dark'
                  ? 'bg-gradient-to-r from-cyan-500 via-purple-500 to-pink-500'
                  : 'bg-gradient-to-r from-cyan-600 via-purple-600 to-pink-600'
              } hover:opacity-90 transition-opacity`}
            >
              {isAnalyzing ? (
                <>
                  <Sparkles className="w-6 h-6 mr-2 animate-spin" />
                  Analyzing for Virality...
                </>
              ) : (
                <>
                  <TrendingUp className="w-6 h-6 mr-2" />
                  Analyze Viral Potential
                </>
              )}
            </Button>
          )}

          {/* Analysis Results */}
          <AnimatePresence>
            {analysisResults && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className={`p-6 rounded-xl border ${
                  theme === 'dark'
                    ? 'bg-gradient-to-br from-cyan-950/40 to-purple-950/40 border-cyan-500/30'
                    : 'bg-gradient-to-br from-cyan-100/60 to-purple-100/60 border-cyan-600/40'
                }`}
              >
                <h3 className={`text-2xl font-bold mb-4 ${
                  theme === 'dark' ? 'text-cyan-300' : 'text-cyan-700'
                }`}>
                  Virality Analysis Results
                </h3>

                {/* Viral Score */}
                <div className="mb-6">
                  <div className="flex items-center justify-between mb-2">
                    <span className={`font-semibold ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                      Viral Potential Score
                    </span>
                    <span className={`text-3xl font-bold ${
                      analysisResults.viralScore >= 70 ? 'text-green-500' :
                      analysisResults.viralScore >= 40 ? 'text-yellow-500' :
                      'text-red-500'
                    }`}>
                      {analysisResults.viralScore}%
                    </span>
                  </div>
                  <div className={`w-full h-3 rounded-full overflow-hidden ${
                    theme === 'dark' ? 'bg-gray-700' : 'bg-gray-300'
                  }`}>
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${analysisResults.viralScore}%` }}
                      transition={{ duration: 1, ease: 'easeOut' }}
                      className={`h-full ${
                        analysisResults.viralScore >= 70 ? 'bg-gradient-to-r from-green-500 to-green-400' :
                        analysisResults.viralScore >= 40 ? 'bg-gradient-to-r from-yellow-500 to-yellow-400' :
                        'bg-gradient-to-r from-red-500 to-red-400'
                      }`}
                    />
                  </div>
                </div>

                {/* Key Insights */}
                <div className="mb-6">
                  <h4 className={`font-semibold mb-3 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                    Key Insights
                  </h4>
                  <ul className="space-y-2">
                    {analysisResults.insights.map((insight, index) => (
                      <li key={index} className={`flex items-start gap-2 ${theme === 'dark' ? 'text-gray-400' : 'text-gray-600'}`}>
                        <span className="text-cyan-500">•</span>
                        <span>{insight}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Recommended Platforms */}
                <div className="mb-6">
                  <h4 className={`font-semibold mb-3 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                    Recommended Platforms
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {analysisResults.platforms.map((platform, index) => (
                      <span
                        key={index}
                        className={`px-4 py-2 rounded-full text-sm font-medium ${
                          theme === 'dark'
                            ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                            : 'bg-purple-200/60 text-purple-700 border border-purple-400/40'
                        }`}
                      >
                        {platform}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex flex-wrap gap-3">
                  <Button
                    onClick={handleDownload}
                    className={`flex-1 ${
                      theme === 'dark' ? 'bg-cyan-500' : 'bg-cyan-600'
                    } hover:opacity-90`}
                  >
                    <Download className="w-5 h-5 mr-2" />
                    Download Optimized
                  </Button>
                  <Button
                    onClick={() => handleShare('tiktok')}
                    className={`${theme === 'dark' ? 'bg-pink-500' : 'bg-pink-600'} hover:opacity-90`}
                  >
                    <Share2 className="w-5 h-5 mr-2" />
                    TikTok
                  </Button>
                  <Button
                    onClick={() => handleShare('instagram')}
                    className={`${theme === 'dark' ? 'bg-purple-500' : 'bg-purple-600'} hover:opacity-90`}
                  >
                    <Share2 className="w-5 h-5 mr-2" />
                    Instagram
                  </Button>
                  <Button
                    onClick={() => handleShare('youtube')}
                    className={`${theme === 'dark' ? 'bg-red-500' : 'bg-red-600'} hover:opacity-90`}
                  >
                    <Share2 className="w-5 h-5 mr-2" />
                    YouTube
                  </Button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}

export default ViralClipMaker;

