import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Volume2, VolumeX } from 'lucide-react';

function IntroScreenV2({ onComplete }) {
  const [showControls, setShowControls] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const videoRef = useRef(null);

  useEffect(() => {
    const videoElement = videoRef.current;

    const handleVideoEnd = () => {
      // Auto-transition when video ends
      handleEnter();
    };

    if (videoElement) {
      videoElement.addEventListener('ended', handleVideoEnd);
      
      // Attempt autoplay with sound
      videoElement.play().catch(error => {
        console.log('Autoplay prevented:', error);
        // If autoplay fails, mute and try again
        videoElement.muted = true;
        setIsMuted(true);
        videoElement.play().catch(e => {
          console.log('Muted autoplay also prevented:', e);
          setShowControls(true);
        });
      });
    }

    // Show controls after 3 seconds
    const timer = setTimeout(() => {
      setShowControls(true);
    }, 3000);

    return () => {
      clearTimeout(timer);
      if (videoElement) {
        videoElement.removeEventListener('ended', handleVideoEnd);
      }
    };
  }, []);

  const handleEnter = () => {
    if (videoRef.current) {
      videoRef.current.pause();
    }
    setIsTransitioning(true);
    
    // Trigger haptic feedback if available
    if (navigator.vibrate) {
      navigator.vibrate([50, 30, 50]);
    }

    // Wait for wormhole animation to complete
    setTimeout(() => {
      onComplete();
    }, 2000);
  };

  const toggleMute = (e) => {
    e.stopPropagation();
    if (videoRef.current) {
      videoRef.current.muted = !videoRef.current.muted;
      setIsMuted(!isMuted);
    }
    
    // Haptic feedback
    if (navigator.vibrate) {
      navigator.vibrate(30);
    }
  };

  return (
    <>
      <motion.div
        initial={{ opacity: 1 }}
        exit={{ 
          opacity: 0,
          scale: 0.8,
          filter: 'blur(20px)',
          transition: { duration: 2, ease: [0.43, 0.13, 0.23, 0.96] }
        }}
        className="fixed inset-0 bg-black flex items-center justify-center overflow-hidden z-50"
        style={{ fontFamily: "'Orbitron', 'Rajdhani', 'Exo 2', sans-serif" }}
      >
        {/* 4K Video Background */}
        <video
          ref={videoRef}
          src="/intro.mp4"
          className="absolute inset-0 w-full h-full object-cover"
          style={{
            objectFit: 'cover',
            width: '100vw',
            height: '100vh',
            filter: isTransitioning ? 'blur(10px)' : 'none',
            transition: 'filter 0.5s ease'
          }}
          muted={isMuted}
          playsInline
          preload="auto"
        />

        {/* Gradient overlay for depth */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-transparent to-black/40 pointer-events-none" />

        {/* Seamless Controls Overlay */}
        <AnimatePresence>
          {showControls && !isTransitioning && (
            <>
              {/* Mute/Unmute Button - Top Right */}
              <motion.button
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                onClick={toggleMute}
                className="absolute top-8 right-8 z-20 p-3 rounded-full backdrop-blur-md bg-white/5 border border-cyan-400/20 hover:border-cyan-400/50 hover:bg-white/10 transition-all duration-300 group"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
              >
                {isMuted ? (
                  <VolumeX className="w-6 h-6 text-cyan-400/70 group-hover:text-cyan-300" />
                ) : (
                  <Volume2 className="w-6 h-6 text-cyan-400/70 group-hover:text-cyan-300" />
                )}
              </motion.button>

              {/* Enter Button - Bottom Center */}
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -30 }}
                transition={{ duration: 1, delay: 0.5 }}
                className="absolute bottom-16 left-0 right-0 flex flex-col items-center gap-4 z-10"
              >
                {/* Main Enter Button */}
                <motion.button
                  onClick={handleEnter}
                  className="relative group"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  {/* Outer glow ring */}
                  <div className="absolute -inset-2 bg-gradient-to-r from-cyan-500/30 via-purple-500/30 to-pink-500/30 rounded-full blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                  
                  {/* Button container */}
                  <div className="relative px-12 py-4 rounded-full backdrop-blur-xl bg-gradient-to-r from-cyan-950/40 via-purple-950/40 to-pink-950/40 border border-cyan-400/30 group-hover:border-cyan-300/60 transition-all duration-300 overflow-hidden">
                    {/* Animated background shimmer */}
                    <motion.div
                      className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent"
                      initial={{ x: '-100%' }}
                      animate={{ x: '200%' }}
                      transition={{ 
                        repeat: Infinity, 
                        duration: 3, 
                        ease: 'linear',
                        repeatDelay: 1
                      }}
                    />
                    
                    {/* Button text */}
                    <span className="relative z-10 text-lg tracking-[0.3em] uppercase font-semibold bg-gradient-to-r from-cyan-300 via-purple-300 to-pink-300 bg-clip-text text-transparent">
                      Enter the Forge
                    </span>
                  </div>
                </motion.button>

                {/* Subtle hint text */}
                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 0.6 }}
                  transition={{ delay: 1.5, duration: 1 }}
                  className="text-xs tracking-widest uppercase text-cyan-400/40"
                >
                  Press Enter or Tap to Continue
                </motion.p>
              </motion.div>
            </>
          )}
        </AnimatePresence>

        {/* High-Quality Wormhole Transition Effect */}
        <AnimatePresence>
          {isTransitioning && (
            <motion.div
              initial={{ scale: 0, opacity: 0, rotate: 0 }}
              animate={{ 
                scale: [0, 1, 2, 5, 20, 50],
                opacity: [0, 0.3, 0.6, 0.8, 1, 1],
                rotate: [0, 45, 90, 180, 360, 720]
              }}
              transition={{ 
                duration: 2,
                times: [0, 0.2, 0.4, 0.6, 0.8, 1],
                ease: [0.43, 0.13, 0.23, 0.96]
              }}
              className="absolute inset-0 flex items-center justify-center pointer-events-none z-30"
            >
              {/* Multi-layered wormhole rings */}
              <div className="relative w-64 h-64">
                {[...Array(8)].map((_, i) => (
                  <motion.div
                    key={i}
                    className="absolute inset-0 rounded-full border-4"
                    style={{
                      borderColor: i % 3 === 0 ? 'rgba(0, 255, 255, 0.6)' : 
                                   i % 3 === 1 ? 'rgba(168, 85, 247, 0.6)' : 
                                   'rgba(236, 72, 153, 0.6)',
                      filter: 'blur(2px)',
                    }}
                    animate={{
                      scale: [1 + i * 0.2, 3 + i * 0.3],
                      opacity: [0.8, 0],
                      rotate: i % 2 === 0 ? 360 : -360
                    }}
                    transition={{
                      duration: 2,
                      delay: i * 0.1,
                      ease: 'easeOut'
                    }}
                  />
                ))}
                
                {/* Central energy core */}
                <motion.div
                  className="absolute inset-0 rounded-full bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500"
                  style={{ filter: 'blur(30px)' }}
                  animate={{
                    scale: [0, 2, 4],
                    opacity: [1, 0.8, 0]
                  }}
                  transition={{ duration: 2 }}
                />
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Keyboard shortcut listener */}
        <div
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && showControls && !isTransitioning) {
              handleEnter();
            }
          }}
          className="absolute inset-0 outline-none"
          style={{ cursor: showControls ? 'pointer' : 'default' }}
        />
      </motion.div>

      {/* Font preload */}
      <link
        href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;600;700;800;900&family=Rajdhani:wght@300;400;500;600;700&family=Exo+2:wght@300;400;500;600;700;800;900&display=swap"
        rel="stylesheet"
      />
    </>
  );
}

export default IntroScreenV2;

