// Design Tokens for NarrativeForge
// Tron/Minority Report/Liminal Aesthetic

export const colors = {
  bg0: "#070b10",
  bg1: "#0b1620",
  bg2: "#0f1a28",
  cyan: "#36d2ff",
  violet: "#a66bff",
  mint: "#6fffe3",
  pink: "#ff6bb5",
  orange: "#ff9f36",
  textHi: "#ecf7ff",
  textLo: "#a9bed1",
  textMuted: "#6b7f94",
  glowCyan: "rgba(54, 210, 255, 0.4)",
  glowViolet: "rgba(166, 107, 255, 0.4)",
  glowMint: "rgba(111, 255, 227, 0.4)",
};

export const fonts = {
  display: "'Michroma', sans-serif",
  body: "'Saira Condensed', sans-serif",
};

export const motion = {
  easing: "cubic-bezier(.2,.8,.2,1)",
  durationFast: "160ms",
  durationMedium: "220ms",
  durationSlow: "400ms",
};

export const gradients = {
  primary: `linear-gradient(135deg, ${colors.cyan}, ${colors.violet})`,
  secondary: `linear-gradient(135deg, ${colors.mint}, ${colors.cyan})`,
  accent: `linear-gradient(135deg, ${colors.pink}, ${colors.orange})`,
  background: `linear-gradient(180deg, ${colors.bg0}, ${colors.bg1})`,
};

