import './App.css';
import TronGridBackground from './components/TronGridBackground';
import VideoIntro from './components/VideoIntro';
import { Routes, Route } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { AnimatePresence } from 'framer-motion';
import IntroScreen from './components/IntroScreen';
import Home from './routes/Home';
import Images from './routes/Images';
import Videos from './routes/Videos';
import Clips from './routes/Clips';
import Characters from './routes/Characters';
import Plots from './routes/Plots';
import Saved from './routes/Saved';
import Dashboard from './routes/Dashboard';
import Download from './routes/Download';

function App() {
  const [videoIntroComplete, setVideoIntroComplete] = useState(() => {
    const saved = sessionStorage.getItem('videoIntroComplete');
    return saved === 'true' ? true : false;
  });
  const [introComplete, setIntroComplete] = useState(() => {
    const saved = localStorage.getItem('introComplete');
    return saved === 'true' ? true : false;
  });
  const [theme, setTheme] = useState('dark');

  useEffect(() => {
    sessionStorage.setItem('videoIntroComplete', videoIntroComplete);
  }, [videoIntroComplete]);

    useEffect(() => {
    localStorage.setItem('introComplete', introComplete);
  }, [introComplete]);

  useEffect(() => {
    // Register service worker
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js');
    }

    // Set initial theme
    document.documentElement.classList.add('dark');
  }, []);

  const toggleTheme = () => {
    const newTheme = theme === 'dark' ? 'light' : 'dark';
    setTheme(newTheme);
    document.documentElement.classList.remove(theme);
    document.documentElement.classList.add(newTheme);
  };

  return (
    <div className="min-h-screen bg-background text-foreground relative">
      <TronGridBackground />
      <AnimatePresence mode="wait">
        {!videoIntroComplete ? (
          <VideoIntro key="video-intro" onComplete={() => setVideoIntroComplete(true)} />
        ) : !introComplete ? (
          <IntroScreen key="intro" onComplete={() => setIntroComplete(true)} />
        ) : (
          <Routes key="app-routes">
            <Route path="/" element={<Home theme={theme} toggleTheme={toggleTheme} />} />
            <Route path="/home" element={<Home theme={theme} toggleTheme={toggleTheme} />} />
            <Route path="/images" element={<Images />} />
            <Route path="/videos" element={<Videos />} />
            <Route path="/clips" element={<Clips />} />
            <Route path="/characters" element={<Characters />} />
            <Route path="/plots" element={<Plots />} />
            <Route path="/saved" element={<Saved />} />
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/download" element={<Download />} />
          </Routes>
        )}
      </AnimatePresence>
    </div>
  );
}

export default App;

