import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

function Dashboard() {
  const stats = [
    { label: 'Stories Generated', value: 0, color: 'from-cyan-500 to-blue-600' },
    { label: 'Images Created', value: 0, color: 'from-blue-500 to-purple-600' },
    { label: 'Videos Produced', value: 0, color: 'from-purple-500 to-pink-600' },
    { label: 'Total Saves', value: 0, color: 'from-pink-500 to-red-600' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 p-8">
      <div className="max-w-6xl mx-auto">
        <Link to="/">
          <Button variant="outline" className="mb-6 border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/20">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Button>
        </Link>
        <h1 className="text-4xl font-bold mb-6 bg-gradient-to-r from-yellow-400 to-green-600 bg-clip-text text-transparent">
          Dashboard
        </h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, index) => (
            <Card key={index} className="bg-gray-900/50 border-cyan-500/30">
              <CardHeader>
                <CardTitle className="text-cyan-400 text-sm">{stat.label}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className={`text-4xl font-bold bg-gradient-to-r ${stat.color} bg-clip-text text-transparent`}>
                  {stat.value}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Dashboard;

