import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Download as DownloadIcon, Smartphone, Monitor } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

function Download() {
  const handleInstallPWA = () => {
    // PWA install prompt
    alert('Click the install button in your browser to install NarrativeForge as a PWA');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 p-8">
      <div className="max-w-4xl mx-auto">
        <Link to="/">
          <Button variant="outline" className="mb-6 border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/20">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Button>
        </Link>
        <h1 className="text-4xl font-bold mb-6 bg-gradient-to-r from-cyan-400 to-purple-600 bg-clip-text text-transparent">
          Download NarrativeForge
        </h1>

        <div className="space-y-6">
          <Card className="bg-gray-900/50 border-cyan-500/30">
            <CardHeader>
              <CardTitle className="text-cyan-400 flex items-center gap-2">
                <Monitor className="h-6 w-6" />
                Web / Desktop (PWA)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-300 mb-4">
                Install NarrativeForge as a Progressive Web App for a native-like experience on desktop and mobile.
              </p>
              <Button
                onClick={handleInstallPWA}
                className="bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-600 hover:to-purple-700"
              >
                <DownloadIcon className="mr-2 h-4 w-4" />
                Install PWA
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-gray-900/50 border-cyan-500/30">
            <CardHeader>
              <CardTitle className="text-cyan-400 flex items-center gap-2">
                <Smartphone className="h-6 w-6" />
                Android
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-300 mb-4">
                Download the Android APK for a native mobile experience.
              </p>
              <Button
                variant="outline"
                className="border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/20"
                disabled
              >
                <DownloadIcon className="mr-2 h-4 w-4" />
                Download APK (Coming Soon)
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-gray-900/50 border-cyan-500/30">
            <CardHeader>
              <CardTitle className="text-cyan-400 flex items-center gap-2">
                <Smartphone className="h-6 w-6" />
                iOS
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-300 mb-4">
                Add NarrativeForge to your home screen on iOS:
              </p>
              <ol className="list-decimal list-inside text-gray-300 space-y-2">
                <li>Open this page in Safari</li>
                <li>Tap the Share button</li>
                <li>Select "Add to Home Screen"</li>
                <li>Tap "Add"</li>
              </ol>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

export default Download;

