import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Sun, Moon, Download, User, LogIn } from 'lucide-react';
import { useState, useEffect, useRef } from 'react';
import TextMediaGenerator from '../components/TextMediaGenerator';

function HomeV2({ theme, toggleTheme }) {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const canvasRef = useRef(null);

  // Tron grid animation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    let animationId;
    let gridOffset = 0;
    let particles = [];

    // Create floating particles
    for (let i = 0; i < 50; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.5,
        vy: (Math.random() - 0.5) * 0.5,
        size: Math.random() * 2 + 1
      });
    }

    const drawTronBackground = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      // Draw grid lines
      ctx.strokeStyle = theme === 'dark' ? 'rgba(0, 255, 255, 0.08)' : 'rgba(0, 100, 150, 0.15)';
      ctx.lineWidth = 1;
      ctx.shadowBlur = 15;
      ctx.shadowColor = theme === 'dark' ? 'rgba(0, 255, 255, 0.3)' : 'rgba(0, 100, 150, 0.2)';

      const gridSize = 60;
      
      // Vertical lines with perspective
      for (let x = 0; x < canvas.width; x += gridSize) {
        const offset = Math.sin((x + gridOffset) / 100) * 10;
        ctx.beginPath();
        ctx.moveTo(x + offset, 0);
        ctx.lineTo(x + offset, canvas.height);
        ctx.stroke();
      }

      // Horizontal lines with perspective
      for (let y = 0; y < canvas.height; y += gridSize) {
        const offset = Math.sin((y + gridOffset) / 100) * 10;
        ctx.beginPath();
        ctx.moveTo(0, y + offset);
        ctx.lineTo(canvas.width, y + offset);
        ctx.stroke();
      }

      // Draw and update particles
      ctx.shadowBlur = 20;
      particles.forEach(p => {
        ctx.fillStyle = theme === 'dark' ? 'rgba(0, 255, 255, 0.6)' : 'rgba(0, 150, 200, 0.4)';
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();

        p.x += p.vx;
        p.y += p.vy;

        if (p.x < 0 || p.x > canvas.width) p.vx *= -1;
        if (p.y < 0 || p.y > canvas.height) p.vy *= -1;
      });

      gridOffset = (gridOffset + 0.3) % gridSize;
      animationId = requestAnimationFrame(drawTronBackground);
    };

    drawTronBackground();

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', handleResize);
    };
  }, [theme]);

  const handleLogin = () => {
    // TODO: Implement actual authentication
    setIsLoggedIn(!isLoggedIn);
    if (navigator.vibrate) {
      navigator.vibrate(30);
    }
  };

  const handleThemeToggle = () => {
    toggleTheme();
    if (navigator.vibrate) {
      navigator.vibrate(50);
    }
  };

  return (
    <div className={`min-h-screen relative overflow-hidden transition-colors duration-500 ${
      theme === 'dark' 
        ? 'bg-gradient-to-br from-gray-950 via-black to-gray-950' 
        : 'bg-gradient-to-br from-gray-100 via-white to-gray-200'
    }`}>
      {/* Tron Grid Background Canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 pointer-events-none opacity-40"
      />

      {/* Ambient glow effects */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-[120px] pointer-events-none" />

      {/* Top Navigation Bar */}
      <nav className={`fixed top-0 left-0 right-0 z-50 backdrop-blur-2xl border-b transition-all duration-300 ${
        theme === 'dark'
          ? 'bg-black/30 border-cyan-500/20'
          : 'bg-white/30 border-cyan-600/30'
      }`}>
        <div className="container mx-auto px-8 py-5 flex justify-between items-center">
          {/* Logo */}
          <motion.h1
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className={`text-3xl font-bold tracking-wider ${
              theme === 'dark'
                ? 'bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400'
                : 'bg-gradient-to-r from-cyan-600 via-purple-600 to-pink-600'
            } bg-clip-text text-transparent`}
            style={{ fontFamily: "'Orbitron', sans-serif", fontWeight: 800 }}
          >
            NARRATIVEFORGE
          </motion.h1>

          {/* Right Controls */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center gap-4"
          >
            {/* Day/Night Toggle */}
            <motion.button
              onClick={handleThemeToggle}
              className={`relative p-3 rounded-xl backdrop-blur-md border transition-all duration-300 group ${
                theme === 'dark'
                  ? 'bg-cyan-950/30 border-cyan-400/30 hover:border-cyan-300/60 hover:bg-cyan-950/50'
                  : 'bg-cyan-100/50 border-cyan-600/40 hover:border-cyan-500/70 hover:bg-cyan-200/60'
              }`}
              whileHover={{ scale: 1.05, rotate: 180 }}
              whileTap={{ scale: 0.95 }}
            >
              <AnimatePresence mode="wait">
                {theme === 'dark' ? (
                  <motion.div
                    key="sun"
                    initial={{ rotate: -90, opacity: 0 }}
                    animate={{ rotate: 0, opacity: 1 }}
                    exit={{ rotate: 90, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <Sun className="h-5 w-5 text-cyan-400 group-hover:text-cyan-300" />
                  </motion.div>
                ) : (
                  <motion.div
                    key="moon"
                    initial={{ rotate: 90, opacity: 0 }}
                    animate={{ rotate: 0, opacity: 1 }}
                    exit={{ rotate: -90, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <Moon className="h-5 w-5 text-cyan-700 group-hover:text-cyan-600" />
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.button>

            {/* Download Button */}
            <Link to="/download">
              <motion.button
                className={`p-3 rounded-xl backdrop-blur-md border transition-all duration-300 group ${
                  theme === 'dark'
                    ? 'bg-purple-950/30 border-purple-400/30 hover:border-purple-300/60 hover:bg-purple-950/50'
                    : 'bg-purple-100/50 border-purple-600/40 hover:border-purple-500/70 hover:bg-purple-200/60'
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Download className={`h-5 w-5 ${
                  theme === 'dark' ? 'text-purple-400 group-hover:text-purple-300' : 'text-purple-700 group-hover:text-purple-600'
                }`} />
              </motion.button>
            </Link>

            {/* Login/Profile Button */}
            <motion.button
              onClick={handleLogin}
              className={`relative p-3 rounded-xl backdrop-blur-md border transition-all duration-300 group ${
                isLoggedIn
                  ? theme === 'dark'
                    ? 'bg-pink-950/30 border-pink-400/30 hover:border-pink-300/60 hover:bg-pink-950/50'
                    : 'bg-pink-100/50 border-pink-600/40 hover:border-pink-500/70 hover:bg-pink-200/60'
                  : theme === 'dark'
                    ? 'bg-gray-950/30 border-gray-400/30 hover:border-gray-300/60 hover:bg-gray-950/50'
                    : 'bg-gray-100/50 border-gray-600/40 hover:border-gray-500/70 hover:bg-gray-200/60'
              }`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              {isLoggedIn ? (
                <>
                  <User className={`h-5 w-5 ${
                    theme === 'dark' ? 'text-pink-400 group-hover:text-pink-300' : 'text-pink-700 group-hover:text-pink-600'
                  }`} />
                  {/* Online indicator */}
                  <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full border-2 border-black animate-pulse" />
                </>
              ) : (
                <LogIn className={`h-5 w-5 ${
                  theme === 'dark' ? 'text-gray-400 group-hover:text-gray-300' : 'text-gray-700 group-hover:text-gray-600'
                }`} />
              )}
            </motion.button>
          </motion.div>
        </div>
      </nav>

      {/* Main Content Area */}
      <div className="relative pt-32 pb-20 px-6 flex items-center justify-center min-h-screen">
        <motion.div
          initial={{ opacity: 0, y: 30, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.8, ease: [0.43, 0.13, 0.23, 0.96] }}
          className="max-w-5xl w-full mx-auto"
        >
          <TextMediaGenerator theme={theme} />
        </motion.div>
      </div>

      {/* Subtle corner accents */}
      <div className={`absolute top-0 left-0 w-64 h-64 border-l-2 border-t-2 rounded-tl-3xl pointer-events-none ${
        theme === 'dark' ? 'border-cyan-500/20' : 'border-cyan-600/30'
      }`} />
      <div className={`absolute bottom-0 right-0 w-64 h-64 border-r-2 border-b-2 rounded-br-3xl pointer-events-none ${
        theme === 'dark' ? 'border-purple-500/20' : 'border-purple-600/30'
      }`} />
    </div>
  );
}

export default HomeV2;

