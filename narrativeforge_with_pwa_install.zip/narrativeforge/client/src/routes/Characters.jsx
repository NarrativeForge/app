import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';

function Characters() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 p-8">
      <div className="max-w-6xl mx-auto">
        <Link to="/">
          <Button variant="outline" className="mb-6 border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/20">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Button>
        </Link>
        <h1 className="text-4xl font-bold mb-6 bg-gradient-to-r from-pink-400 to-red-600 bg-clip-text text-transparent">
          Characters
        </h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="bg-gray-900/50 border border-cyan-500/30 rounded-lg p-6 text-center">
            <p className="text-cyan-300">Your character profiles will appear here</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Characters;

