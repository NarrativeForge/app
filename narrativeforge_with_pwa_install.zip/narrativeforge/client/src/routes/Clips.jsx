import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { motion } from 'framer-motion';
import ViralClipMaker from '../components/ViralClipMaker';
import { DockBar } from '../ui';
import { colors, fonts } from '../tokens';

function Clips() {
  return (
    <div className="min-h-screen relative">
      {/* Hero Section */}
      <div className="pt-20 pb-12 px-6 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="text-center mb-12"
        >
          <h1 
            className="text-5xl md:text-6xl font-bold mb-4"
            style={{ 
              fontFamily: fonts.display,
              color: colors.cyan,
              textShadow: `0 0 20px ${colors.cyan}, 0 0 40px ${colors.cyan}`,
              letterSpacing: '0.2em',
            }}
          >
            VIRAL CLIP MAKER
          </h1>
          <p 
            className="text-lg md:text-xl"
            style={{ 
              color: colors.textLo,
              fontFamily: fonts.display,
              letterSpacing: '0.15em',
              fontSize: '0.9rem',
            }}
          >
            AI-POWERED VIDEO OPTIMIZATION
          </p>
        </motion.div>

        {/* Viral Clip Maker Component */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="max-w-6xl mx-auto"
        >
          <ViralClipMaker theme="dark" />
        </motion.div>
      </div>

      {/* Dock Bar */}
      <DockBar />
    </div>
  );
}

export default Clips;

