import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Sun, Moon, Download, LogOut } from 'lucide-react';
import { GlassButton, DockBar } from '../ui';
import { colors, fonts } from '../tokens';
import TextMediaGenerator from '../components/TextMediaGenerator';
import ShowcaseGallery from '../components/ShowcaseGallery';
import InstallPWAButton from '../components/InstallPWAButton';

function Home({ theme, toggleTheme }) {
  return (
    <div className="min-h-screen relative">
      {/* Hero Section */}
      <div className="pt-20 pb-32 px-6 flex flex-col items-center justify-center min-h-screen relative z-10">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="text-center mb-12"
        >
          <h1 
            className="text-6xl md:text-7xl font-bold mb-6"
            style={{ 
              fontFamily: fonts.display,
              color: colors.cyan,
              textShadow: `0 0 20px ${colors.cyan}, 0 0 40px ${colors.cyan}, 0 0 60px ${colors.cyan}, 0 0 80px ${colors.cyan}`,
              letterSpacing: '0.2em',
            }}
          >
            NARRATIVEFORGE
          </h1>
          <p 
            className="text-lg md:text-xl mb-8"
            style={{ 
              color: colors.textLo,
              fontFamily: fonts.display,
              letterSpacing: '0.15em',
              fontSize: '0.9rem',
            }}
          >
            AI-POWERED STORY GENERATION SYSTEM
          </p>
          
          {/* Install PWA Button */}
          <div className="flex justify-center mb-8">
            <InstallPWAButton />
          </div>
          
          {/* Decorative divider */}
          <div className="flex items-center gap-4 mb-8">
            <div className="h-px flex-1" style={{ background: `linear-gradient(to right, transparent, ${colors.cyan}, transparent)` }} />
            <div 
              className="w-3 h-3 rounded-full"
              style={{ 
                background: colors.cyan,
                boxShadow: `0 0 10px ${colors.cyan}, 0 0 20px ${colors.cyan}`,
              }}
            />
            <div className="h-px flex-1" style={{ background: `linear-gradient(to right, transparent, ${colors.cyan}, transparent)` }} />
          </div>
        </motion.div>

        {/* Showcase Gallery */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.6 }}
        >
          <ShowcaseGallery />
        </motion.div>

        {/* Main Generator */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="max-w-5xl w-full mx-auto"
        >
          <TextMediaGenerator />
        </motion.div>
      </div>

      {/* Dock Bar */}
      <DockBar />
    </div>
  );
}

export default Home;

