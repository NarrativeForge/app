import React from 'react';
import { motion } from 'framer-motion';
import { colors } from '../tokens';

const TronButton = ({ 
  children, 
  active = false, 
  onClick, 
  variant = 'default',
  className = '',
  ...props 
}) => {
  return (
    <motion.button
      onClick={onClick}
      className={`relative px-4 py-2 rounded border overflow-hidden ${className}`}
      style={{
        background: active ? `${colors.cyan}15` : 'rgba(0, 0, 0, 0.4)',
        borderColor: active ? colors.cyan : `${colors.cyan}30`,
        color: active ? colors.cyan : colors.textLo,
        fontFamily: "'Michroma', sans-serif",
        fontSize: '0.75rem',
        letterSpacing: '0.05em',
        textTransform: 'uppercase',
        boxShadow: active ? `0 0 15px ${colors.glowCyan}, 0 0 30px ${colors.glowCyan}` : 'none',
        textShadow: active ? `0 0 8px ${colors.cyan}` : 'none',
      }}
      whileHover={{
        borderColor: colors.cyan,
        boxShadow: `0 0 15px ${colors.glowCyan}`,
        scale: 1.02,
      }}
      whileTap={{ scale: 0.98 }}
      transition={{ duration: 0.16, ease: [0.2, 0.8, 0.2, 1] }}
      {...props}
    >
      {/* Scan line effect on hover */}
      <motion.div
        className="absolute inset-0 h-full pointer-events-none"
        style={{
          background: `linear-gradient(to bottom, transparent, ${colors.cyan}20, transparent)`,
          opacity: 0,
        }}
        whileHover={{
          opacity: 1,
          y: ['-100%', '200%'],
        }}
        transition={{
          y: {
            duration: 1.5,
            repeat: Infinity,
            ease: 'linear',
          },
          opacity: {
            duration: 0.3,
          },
        }}
      />

      {/* Corner brackets when active */}
      {active && (
        <>
          {[
            { top: 0, left: 0, rotate: 0 },
            { top: 0, right: 0, rotate: 90 },
            { bottom: 0, right: 0, rotate: 180 },
            { bottom: 0, left: 0, rotate: 270 },
          ].map((pos, i) => (
            <motion.div
              key={i}
              className="absolute w-2 h-2"
              style={{
                ...pos,
                borderTop: `1px solid ${colors.cyan}`,
                borderLeft: `1px solid ${colors.cyan}`,
                transform: `rotate(${pos.rotate}deg)`,
                boxShadow: `0 0 3px ${colors.cyan}`,
              }}
              initial={{ opacity: 0, scale: 0 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.3, delay: i * 0.05 }}
            />
          ))}
        </>
      )}

      {/* Content */}
      <span className="relative z-10">{children}</span>

      {/* Shimmer effect on click */}
      <motion.div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: `radial-gradient(circle at 50% 50%, ${colors.cyan}40, transparent 60%)`,
          filter: 'blur(15px)',
          opacity: 0,
        }}
        whileTap={{
          opacity: [0, 0.8, 0],
          scale: [0.5, 1.5, 2],
        }}
        transition={{ duration: 0.6 }}
      />
    </motion.button>
  );
};

export default TronButton;

