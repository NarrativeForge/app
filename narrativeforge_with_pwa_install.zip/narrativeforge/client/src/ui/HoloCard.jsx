import React from 'react';
import { motion } from 'framer-motion';
import { colors } from '../tokens';

const HoloCard = ({ 
  children, 
  className = '',
  glowColor = colors.cyan,
  ...props 
}) => {
  return (
    <motion.div
      className={`
        relative rounded-2xl p-6
        backdrop-blur-xl border
        ${className}
      `}
      style={{
        background: 'rgba(11, 22, 32, 0.6)',
        borderColor: `${glowColor}40`,
        boxShadow: `0 0 20px ${glowColor}20, inset 0 0 20px ${glowColor}10`,
      }}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.22, ease: [0.2, 0.8, 0.2, 1] }}
      whileHover={{
        boxShadow: `0 0 30px ${glowColor}30, inset 0 0 30px ${glowColor}15`,
        borderColor: `${glowColor}60`,
      }}
      {...props}
    >
      {/* Neon border pulse effect */}
      <motion.div
        className="absolute inset-0 rounded-2xl pointer-events-none"
        style={{
          border: `1px solid ${glowColor}`,
          opacity: 0.3,
        }}
        animate={{
          opacity: [0.3, 0.6, 0.3],
        }}
        transition={{
          duration: 2,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
      />
      
      {/* Content */}
      <div className="relative z-10">
        {children}
      </div>
    </motion.div>
  );
};

export default HoloCard;

