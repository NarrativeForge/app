import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { colors } from '../tokens';

const TypeField = ({ 
  value,
  onChange,
  placeholder = "Describe a scene...",
  multiline = false,
  rows = 4,
  className = '',
  ...props 
}) => {
  const [isFocused, setIsFocused] = useState(false);

  const InputComponent = multiline ? 'textarea' : 'input';

  return (
    <motion.div
      className={`relative ${className}`}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.22 }}
    >
      <InputComponent
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        rows={multiline ? rows : undefined}
        onFocus={() => setIsFocused(true)}
        onBlur={() => setIsFocused(false)}
        className={`
          w-full px-4 py-3 rounded-xl
          bg-gray-900/80 backdrop-blur-md
          border transition-all duration-200
          text-white placeholder-gray-500
          focus:outline-none
          ${multiline ? 'resize-none' : ''}
        `}
        style={{
          borderColor: isFocused ? colors.cyan : 'rgba(255, 255, 255, 0.1)',
          boxShadow: isFocused 
            ? `0 0 20px ${colors.glowCyan}, inset 0 0 10px ${colors.glowCyan}` 
            : '0 2px 8px rgba(0, 0, 0, 0.2)',
          caretColor: colors.cyan,
        }}
        {...props}
      />
      
      {/* Animated placeholder */}
      {!value && !isFocused && (
        <motion.div
          className="absolute left-4 top-3 pointer-events-none text-gray-500"
          initial={{ opacity: 0 }}
          animate={{ opacity: [0.5, 1, 0.5] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          {placeholder}
        </motion.div>
      )}
      
      {/* Cyan cursor indicator */}
      {isFocused && (
        <motion.div
          className="absolute right-3 top-3 w-1 h-5 rounded-full"
          style={{ background: colors.cyan }}
          animate={{ opacity: [1, 0, 1] }}
          transition={{ duration: 0.8, repeat: Infinity }}
        />
      )}
    </motion.div>
  );
};

export default TypeField;

