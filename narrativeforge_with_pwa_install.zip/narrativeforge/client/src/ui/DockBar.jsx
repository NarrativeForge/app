import React from 'react';
import { motion } from 'framer-motion';
import { useNavigate, useLocation } from 'react-router-dom';
import { Home, Image, Video, Scissors, User } from 'lucide-react';
import { colors } from '../tokens';

const DockBar = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const navItems = [
    { icon: Home, path: '/', label: 'Home' },
    { icon: Image, path: '/images', label: 'Images' },
    { icon: Video, path: '/videos', label: 'Videos' },
    { icon: Scissors, path: '/clips', label: 'Clips' },
    { icon: User, path: '/dashboard', label: 'Profile' },
  ];

  return (
    <motion.div
      className="fixed bottom-6 left-1/2 transform -translate-x-1/2 z-50"
      initial={{ y: 100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.4, ease: [0.2, 0.8, 0.2, 1] }}
    >
      <div
        className="flex items-center gap-2 px-6 py-3 rounded-full backdrop-blur-xl border border-white/10"
        style={{
          background: 'rgba(11, 22, 32, 0.8)',
          boxShadow: `0 8px 32px rgba(0, 0, 0, 0.4), 0 0 20px ${colors.glowCyan}`,
        }}
      >
        {navItems.map((item, index) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;

          return (
            <motion.button
              key={item.path}
              onClick={() => navigate(item.path)}
              className="relative p-3 rounded-full transition-all duration-200"
              style={{
                background: isActive 
                  ? `linear-gradient(135deg, ${colors.cyan}, ${colors.violet})` 
                  : 'transparent',
              }}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              transition={{ duration: 0.16 }}
            >
              <Icon
                size={24}
                style={{
                  color: isActive ? 'white' : colors.textLo,
                }}
              />
              
              {/* Active indicator */}
              {isActive && (
                <motion.div
                  className="absolute -bottom-1 left-1/2 transform -translate-x-1/2 w-1 h-1 rounded-full"
                  style={{ background: colors.cyan }}
                  layoutId="activeIndicator"
                  transition={{ duration: 0.22, ease: [0.2, 0.8, 0.2, 1] }}
                />
              )}
            </motion.button>
          );
        })}
      </div>
      
      {/* Reflection effect */}
      <div
        className="absolute inset-0 rounded-full opacity-20 pointer-events-none"
        style={{
          background: `linear-gradient(180deg, transparent 50%, ${colors.cyan}20 100%)`,
          filter: 'blur(8px)',
        }}
      />
    </motion.div>
  );
};

export default DockBar;

