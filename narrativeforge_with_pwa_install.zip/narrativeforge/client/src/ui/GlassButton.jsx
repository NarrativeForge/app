import React from 'react';
import { motion } from 'framer-motion';
import { colors, motion as motionTokens } from '../tokens';

const GlassButton = ({ 
  children, 
  onClick, 
  variant = 'primary', 
  size = 'medium',
  disabled = false,
  className = '',
  ...props 
}) => {
  const variants = {
    primary: {
      background: `linear-gradient(135deg, ${colors.cyan}, ${colors.violet})`,
      glow: colors.glowCyan,
    },
    secondary: {
      background: `linear-gradient(135deg, ${colors.mint}, ${colors.cyan})`,
      glow: colors.glowMint,
    },
    accent: {
      background: `linear-gradient(135deg, ${colors.pink}, ${colors.orange})`,
      glow: 'rgba(255, 107, 181, 0.4)',
    },
  };

  const sizes = {
    small: 'px-4 py-2 text-sm',
    medium: 'px-6 py-3 text-base',
    large: 'px-8 py-4 text-lg',
  };

  const currentVariant = variants[variant] || variants.primary;
  const currentSize = sizes[size] || sizes.medium;

  return (
    <motion.button
      onClick={onClick}
      disabled={disabled}
      className={`
        relative rounded-full font-semibold text-white
        backdrop-blur-md border border-white/20
        ${currentSize}
        ${disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}
        ${className}
      `}
      style={{
        background: currentVariant.background,
        boxShadow: `0 0 20px ${currentVariant.glow}, 0 4px 12px rgba(0, 0, 0, 0.3)`,
      }}
      whileHover={!disabled ? {
        scale: 1.05,
        boxShadow: `0 0 30px ${currentVariant.glow}, 0 6px 16px rgba(0, 0, 0, 0.4)`,
      } : {}}
      whileTap={!disabled ? { scale: 0.95 } : {}}
      transition={{ 
        duration: 0.16,
        ease: [0.2, 0.8, 0.2, 1],
      }}
      {...props}
    >
      <span className="relative z-10">{children}</span>
    </motion.button>
  );
};

export default GlassButton;

