const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const OpenAI = require('openai');
const Replicate = require('replicate');
const multer = require('multer');
const { exec } = require('child_process');
const { promisify } = require('util');
const fs = require('fs').promises;
const path = require('path');
const execAsync = promisify(exec);

dotenv.config();

const app = express();
const PORT = process.env.PORT || 8080;

// Middleware
app.use(cors({
  origin: process.env.CLIENT_URL || 'http://localhost:5173',
  credentials: true,
}));
app.use(express.json());

// Configure multer for video uploads
const upload = multer({
  dest: 'uploads/',
  limits: { fileSize: 500 * 1024 * 1024 }, // 500MB max
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('video/')) {
      cb(null, true);
    } else {
      cb(new Error('Only video files are allowed'));
    }
  }
});

// Ensure uploads directory exists
const uploadsDir = path.join(__dirname, 'uploads');
fs.mkdir(uploadsDir, { recursive: true }).catch(console.error);

// Initialize AI clients
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

const replicate = new Replicate({
  auth: process.env.REPLICATE_API_TOKEN,
});

// Text generation endpoint
app.post('/api/gen/text', async (req, res) => {
  try {
    const { mode, prompt, length, tone, style } = req.body;

    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    // Build system message based on parameters
    let systemMessage = `You are a creative writer specializing in ${mode}. `;
    systemMessage += `Write in a ${tone} tone with a ${style} style. `;
    
    const lengthGuide = {
      short: '100-200 words',
      medium: '300-500 words',
      long: '600-1000 words'
    };
    systemMessage += `The output should be approximately ${lengthGuide[length] || lengthGuide.medium}.`;

    const completion = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: systemMessage },
        { role: 'user', content: prompt }
      ],
      max_tokens: length === 'long' ? 2000 : length === 'medium' ? 1000 : 500,
    });

    const text = completion.choices[0].message.content;

    res.json({
      id: Date.now().toString(),
      status: 'completed',
      text,
      meta: { mode, length, tone, style }
    });
  } catch (error) {
    console.error('Text generation error:', error);
    res.status(500).json({ error: error.message || 'Text generation failed' });
  }
});

// Image generation endpoint
app.post('/api/gen/image', async (req, res) => {
  try {
    const { prompt, aspect = '1:1', steps = 30, guidance = 7.5 } = req.body;

    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    // Map aspect ratio to dimensions
    const aspectMap = {
      '1:1': { width: 1024, height: 1024 },
      '16:9': { width: 1344, height: 768 },
      '9:16': { width: 768, height: 1344 }
    };

    const dimensions = aspectMap[aspect] || aspectMap['1:1'];

    // Using Replicate's FLUX model for image generation
    const output = await replicate.run(
      "black-forest-labs/flux-schnell",
      {
        input: {
          prompt,
          num_outputs: 1,
          aspect_ratio: aspect,
          output_format: "png",
          output_quality: 90
        }
      }
    );

    const imageUrl = Array.isArray(output) ? output[0] : output;

    res.json({
      id: Date.now().toString(),
      status: 'completed',
      url: imageUrl,
      meta: { prompt, aspect, steps, guidance }
    });
  } catch (error) {
    console.error('Image generation error:', error);
    res.status(500).json({ error: error.message || 'Image generation failed' });
  }
});

// Image-to-video endpoint
app.post('/api/gen/image-to-video', async (req, res) => {
  try {
    const { prompt, imageUrl, motionStyle = 'default' } = req.body;

    if (!prompt && !imageUrl) {
      return res.status(400).json({ error: 'Prompt or image URL is required' });
    }

    // Using Replicate's Stable Video Diffusion or similar model
    const output = await replicate.run(
      "stability-ai/stable-video-diffusion",
      {
        input: {
          input_image: imageUrl || prompt,
          motion_bucket_id: 127,
          frames_per_second: 6,
          num_frames: 25
        }
      }
    );

    const videoUrl = Array.isArray(output) ? output[0] : output;

    res.json({
      id: Date.now().toString(),
      status: 'completed',
      url: videoUrl,
      meta: { prompt, imageUrl, motionStyle }
    });
  } catch (error) {
    console.error('Video generation error:', error);
    res.status(500).json({ error: error.message || 'Video generation failed' });
  }
});

// Viral Clip Maker endpoint
app.post('/api/viral/analyze', upload.single('video'), async (req, res) => {
  let videoPath = null;
  let framesDir = null;
  
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'Video file is required' });
    }

    videoPath = req.file.path;
    framesDir = path.join(uploadsDir, `frames_${Date.now()}`);
    await fs.mkdir(framesDir, { recursive: true });

    // Step 1: Get video duration and metadata
    const { stdout: probeOutput } = await execAsync(
      `ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nokey=1 "${videoPath}"`
    );
    const duration = parseFloat(probeOutput.trim());

    // Step 2: Extract key frames for AI analysis (every 5 seconds, max 10 frames)
    const frameInterval = Math.max(5, duration / 10);
    const numFrames = Math.min(10, Math.floor(duration / frameInterval));
    
    const framePromises = [];
    for (let i = 0; i < numFrames; i++) {
      const timestamp = i * frameInterval;
      const framePath = path.join(framesDir, `frame_${i}.jpg`);
      framePromises.push(
        execAsync(
          `ffmpeg -ss ${timestamp} -i "${videoPath}" -vframes 1 -q:v 2 "${framePath}"`
        )
      );
    }
    await Promise.all(framePromises);

    // Step 3: Analyze frames with OpenAI Vision
    const frameFiles = await fs.readdir(framesDir);
    const frameAnalyses = [];
    
    for (const frameFile of frameFiles.slice(0, 5)) { // Analyze first 5 frames to save costs
      const framePath = path.join(framesDir, frameFile);
      const imageBuffer = await fs.readFile(framePath);
      const base64Image = imageBuffer.toString('base64');
      
      const analysis = await openai.chat.completions.create({
        model: 'gpt-4o-mini',
        messages: [
          {
            role: 'user',
            content: [
              {
                type: 'text',
                text: 'Analyze this video frame for viral potential. Consider: 1) Visual appeal 2) Hook/attention-grabbing elements 3) Emotional impact 4) Shareability. Rate each aspect 1-10 and explain briefly.'
              },
              {
                type: 'image_url',
                image_url: {
                  url: `data:image/jpeg;base64,${base64Image}`
                }
              }
            ]
          }
        ],
        max_tokens: 300
      });
      
      frameAnalyses.push(analysis.choices[0].message.content);
    }

    // Step 4: Generate overall viral analysis
    const overallAnalysis = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        {
          role: 'system',
          content: 'You are a social media expert analyzing video content for viral potential. Provide a viral score (0-100), key insights, and recommended platforms.'
        },
        {
          role: 'user',
          content: `Video duration: ${duration.toFixed(1)}s\n\nFrame analyses:\n${frameAnalyses.join('\n\n')}\n\nBased on this, provide:\n1. Viral score (0-100)\n2. 3-5 key insights\n3. Best platforms (TikTok, Instagram Reels, YouTube Shorts, Twitter)\n4. Recommended clip duration (15s, 30s, or 60s)\n5. Best starting timestamp for the clip\n\nFormat as JSON: {"viralScore": number, "insights": [string], "platforms": [string], "clipDuration": number, "startTime": number}`
        }
      ],
      response_format: { type: 'json_object' }
    });

    const analysisResult = JSON.parse(overallAnalysis.choices[0].message.content);

    // Step 5: Extract optimized clip
    const clipPath = path.join(uploadsDir, `clip_${Date.now()}.mp4`);
    const startTime = analysisResult.startTime || 0;
    const clipDuration = analysisResult.clipDuration || 30;
    
    await execAsync(
      `ffmpeg -ss ${startTime} -i "${videoPath}" -t ${clipDuration} -c:v libx264 -preset fast -crf 23 -c:a aac -b:a 128k "${clipPath}"`
    );

    // Generate public URL for the clip (in production, upload to S3/CDN)
    const clipUrl = `/uploads/${path.basename(clipPath)}`;

    // Step 6: Clean up frames directory
    await fs.rm(framesDir, { recursive: true, force: true });

    res.json({
      viralScore: analysisResult.viralScore,
      insights: analysisResult.insights,
      platforms: analysisResult.platforms,
      optimizedVideo: clipUrl,
      clipDuration,
      originalDuration: duration
    });

  } catch (error) {
    console.error('Viral analysis error:', error);
    res.status(500).json({ error: error.message || 'Video analysis failed' });
  } finally {
    // Clean up uploaded video after processing
    if (videoPath) {
      fs.unlink(videoPath).catch(console.error);
    }
    // Clean up frames directory if it still exists
    if (framesDir) {
      fs.rm(framesDir, { recursive: true, force: true }).catch(console.error);
    }
  }
});

// Serve uploaded files
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Start server
app.listen(PORT, () => {
  console.log(`NarrativeForge server running on port ${PORT}`);
  console.log(`Health check: http://localhost:${PORT}/health`);
});

